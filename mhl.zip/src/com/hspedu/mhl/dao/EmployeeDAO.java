package com.hspedu.mhl.dao;

import com.hspedu.mhl.domain.Employee;

/**
 * @author 韩顺平
 * @version 1.0
 */
public class EmployeeDAO extends BasicDAO<Employee> {
    //这里还可以写特有的操作.
}

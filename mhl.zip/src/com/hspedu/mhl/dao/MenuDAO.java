package com.hspedu.mhl.dao;

import com.hspedu.mhl.domain.Menu;

/**
 * @author 韩顺平
 * @version 1.0
 */
public class MenuDAO extends BasicDAO<Menu> {
}

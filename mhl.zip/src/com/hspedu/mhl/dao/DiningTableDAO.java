package com.hspedu.mhl.dao;

import com.hspedu.mhl.domain.DiningTable;

/**
 * @author 韩顺平
 * @version 1.0
 */
public class DiningTableDAO extends BasicDAO<DiningTable> {
    //如果有特别的操作，可以写在 DiningTableDAO
}

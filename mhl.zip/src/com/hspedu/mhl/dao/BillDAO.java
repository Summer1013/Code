package com.hspedu.mhl.dao;

import com.hspedu.mhl.domain.Bill;

/**
 * @author 韩顺平
 * @version 1.0
 */
public class BillDAO extends BasicDAO<Bill> {
}

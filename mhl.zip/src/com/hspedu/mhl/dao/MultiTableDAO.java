package com.hspedu.mhl.dao;

import com.hspedu.mhl.domain.MultiTableBean;

/**
 * @author 韩顺平
 * @version 1.0
 */
public class MultiTableDAO extends BasicDAO<MultiTableBean> {
}

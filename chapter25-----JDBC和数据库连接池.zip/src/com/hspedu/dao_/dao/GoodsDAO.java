package com.hspedu.dao_.dao;

import com.hspedu.dao_.domain.Goods;

public class GoodsDAO extends BasicDAO<Goods>{

}

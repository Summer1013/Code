package com.yuwei.jdbc.myjdbc;

public class TestJDBC {
    public static void main(String[] args) {
        JdbcInterface jdbcInterface = new MysqlJdbcImplement();
        jdbcInterface.getConnection();
        jdbcInterface.crud();
        jdbcInterface.close();

        jdbcInterface = new OracleJdbcImplement();
        jdbcInterface.getConnection();
        jdbcInterface.crud();
        jdbcInterface.close();




    }
}

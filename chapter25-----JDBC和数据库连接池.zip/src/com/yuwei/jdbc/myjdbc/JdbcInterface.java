package com.yuwei.jdbc.myjdbc;

public interface JdbcInterface {
    public Object getConnection();

    public void crud();

    public void close();
}

package com.yuwei.jdbc.statement_;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;

@SuppressWarnings({"all"})
public class PreparedStatement_ {
    public static void main(String[] args) throws IOException, SQLException, ClassNotFoundException {
        Properties properties = new Properties();
        properties.load(new FileInputStream("src\\mysql.properties"));
        String user = properties.getProperty("user");
        String password = properties.getProperty("password");
        String url = properties.getProperty("url");
        String driver = properties.getProperty("driver");
        Class.forName(driver);
        Connection connection = DriverManager.getConnection(url, user, password);
//        String sql = "insert into admin values('tom','123'),('jack','123')," +
//                "('john','123'),('smith','123'),('yuwei','123')";
//        String sql = "update admin set username = 'king' where username = 'tom'";
        //String sql = "delete from admin where username = 'yuwei'";
        String sql = "select * from admin";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()){
            String username = resultSet.getString(1);
            //String username = resultSet.getString("username");
            password = resultSet.getString(2);
            System.out.println(username + "\t\t" + password);
        }
        resultSet.close();
        connection.close();
        preparedStatement.close();

    }
}

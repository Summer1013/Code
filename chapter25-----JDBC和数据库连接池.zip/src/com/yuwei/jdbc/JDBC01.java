package com.yuwei.jdbc;

import com.mysql.jdbc.Driver;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class JDBC01 {
    public static void main(String[] args) throws SQLException {


        //1.注册驱动
        Driver driver = new Driver();
        //2.得到连接
        String url = "jdbc:mysql://localhost:3306/hsp_db02";
        Properties properties = new Properties();
        properties.setProperty("user", "root");
        properties.setProperty("password", "hsp");
        Connection connect = driver.connect(url, properties);
        //3.执行sql
        //String sql = "insert into actor values(null, '夏天', '男', '2000-10-13 22:22:22', '17736754801')";
        //String sql = "update actor set name = '鱼尾' where id = 1";
        String sql = "delete from action id = 1";
        Statement statement = connect.createStatement();
        int i = statement.executeUpdate(sql);
        System.out.println(i > 0 ? "成功" : "失败");
        //4.关闭连接资源
        statement.close();
        connect.close();




    }
}

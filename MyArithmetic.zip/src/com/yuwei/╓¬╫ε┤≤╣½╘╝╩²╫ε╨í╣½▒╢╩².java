package com.yuwei;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

/**
 * @author 于伟
 * 做什么:
 */
public class 知最大公约数最小公倍数 {
    //第一次尝试写出
    //已知最小公倍数和最大公约数怎么求出  这两个数 100以内
    //1.进入第一个循环,如果这个数满足对最大公约数取余等于0并且最小公倍数对这个数取余也等于0 如果不满足则加1再判断
    //2.进入第二个循环,如果另外一个数也满足对最大公约数取余等于0并且最小公倍数对这个数取余也等于0 如果不满足则加1再判断
    //有错误  第二个循环每次到了最大公约数就停止了  所以后面这个数就会一直是最大公约数
    public static void test01(){
        int num1,num2;
        Scanner scanner = new Scanner(System.in);
        System.out.print("请输入最小公倍数 = ");
        num1 = scanner.nextInt();
        System.out.print("请输入最大公约数 = ");
        num2 = scanner.nextInt();
        for (int k = 1; k <= 100; k++) {
            if(k % num2 == 0  && num1 % k == 0){
                for (int l = 1; l <= 100 ; l++) {
                    if(l % num2 == 0  && num1 % l == 0){
                        System.out.println(k + "," + l);
                        break;
                    }
                }
            }
        }
    }

    //第一次改进  可以做一个集合 存满足的所有数 最后再取出
    //结果太多了 太乱了 有一些不符合要求的结果
    public static void test02(){
        int num1,num2;
        List list = new ArrayList();
        Scanner scanner = new Scanner(System.in);
        System.out.print("请输入最小公倍数 = ");
        num1 = scanner.nextInt();
        System.out.print("请输入最大公约数 = ");
        num2 = scanner.nextInt();
        for (int k = 1; k <= 100; k++) {
            if(k % num2 == 0  && num1 % k == 0){
                for (int l = 1; l <= 100 ; l++) {
                    if(l % num2 == 0  && num1 % l == 0){
                        if(k == l){

                        }else {
                            list.add(k+","+l);
                        }
                    }
                }
            }
        }
        Iterator iterator = list.iterator();
        while (iterator.hasNext()){
            System.out.println(iterator.next());
        }
    }

    //第二次改进 我们算出了两位后再通过这两位数去得到最小公倍数和最大公约数 再进行比对

    public static void test03(){
        int num1,num2,flag=0,k,l,i,j,count = 0;
        List list = new ArrayList();
        Scanner scanner = new Scanner(System.in);
        System.out.print("请输入最小公倍数 = ");
        num1 = scanner.nextInt();
        System.out.print("请输入最大公约数 = ");
        num2 = scanner.nextInt();
        for (k = 1; k <= 100; k++) {//k为一个数
            if(k % num2 == 0  && num1 % k == 0){//第一个数满足对最大公约数取余等于0并且最小公倍数对这个数取余也等于0
                for (l = 1; l <= 100 ; l++) {//l为另一个数
                    if(l % num2 == 0  && num1 % l == 0){//第二个数满足对最大公约数取余等于0并且最小公倍数对这个数取余也等于0
                        //让k为这两个数中较大的一个
                        if(k < l){
                            int temp = k;
                            k = l;
                            l = temp;
                        }
                        //求出这两个数的最小公倍数 与 我们输入的最小公倍数对比  第一次比对
                        for (i = k; i > 0; i++){
                            if(i%k == 0 && i%l == 0){
                                if(i == num1){
                                    flag++;
                                }
                                break;
                            } else {
                                continue;
                            }
                        }
                        //求出这两个数的大公约数 与 我们输入的最大公约数对比   第二次比对
                        for (j = l;j >= 1;j--) {
                            if(k%j == 0 && l%j == 0){
                                if(j == num2){
                                   flag++;
                                }
                                break;
                            }
                        }
                        //如果两次比对都成功 则添加进list集合
                        if (flag == 2){
                            if(k != l) {
                                list.add(k + "," + l);
                            }
                        }else {
                            flag = 0;
                        }
                    }else {
                        continue;
                    }
                }
            }else {
                continue;
            }
        }
        Iterator iterator = list.iterator();
        while (iterator.hasNext()){
            System.out.println(iterator.next());
        }
    }

    public static void test04(){

    }


    public static void main(String[] args) {
        test03();
    }
}

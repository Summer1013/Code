package com.yuwei;

import java.lang.reflect.ParameterizedType;
import java.sql.SQLOutput;
import java.util.Scanner;

/**
 * @author 于伟
 * 做什么:
 */
public class 求最大公约数最小公倍数 {
    public static void main(String[] args) {
        int num1,num2,i,j;

        Scanner scanner = new Scanner(System.in);
        System.out.println("下面要输入两个数来 求最小公倍数和最大公约数了");
        System.out.print("请输入第一个数: ");
        num1 = scanner.nextInt();
        System.out.print("请输入第二个数: ");
        num2 = scanner.nextInt();

        //让num1为较大的数字
        if(num1 < num2){
            int temp = num1;
            num1 = num2;
            num2 = temp;
        }

        //求最小公倍数
        for (i = num1;i > 0;i++){
            if(i%num1 == 0 && i%num2 == 0){
                System.out.println(num1 + "和" +num2 + "的最小公倍数为 " + i);
                break;
            }
        }

        //求最大公约数
        for (j = num2;j >= 1;j--) {
            if(num1%j == 0 && num2%j == 0){
                System.out.println(num1 + "和" +num2 + "的最大公约数为 " + j);
                break;
            }
        }

    }
}

import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;

/**
 * @author 夏天
 * 有bug请联系QQ:1205232048
 * 做什么:
 */
class Test {
    private static Test t1 = new Test();
    private static Test t2 = new Test();
    private static Test t4 = new Test();

    static {
        System.out.println("静态块");
    }

    {
        System.out.println("构造块");
    }

    public static void main(String[] args) {
        Test t3 = new Test();
    }
}

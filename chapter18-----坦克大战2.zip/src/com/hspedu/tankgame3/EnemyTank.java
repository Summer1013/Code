package com.hspedu.tankgame3;

/**
 * @author 韩顺平
 * @version 1.0
 * 敌人的坦克
 */
public class EnemyTank extends Tank {
    public EnemyTank(int x, int y) {
        super(x, y);
    }
}

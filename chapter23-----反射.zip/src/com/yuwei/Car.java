package com.yuwei;

public class Car {
    public String brand = "迈巴赫";
    public String price = "5000000";
    public String color = "黑色";

    @Override
    public String toString() {
        return "Car{" +
                "brand='" + brand + '\'' +
                ", price='" + price + '\'' +
                ", color='" + color + '\'' +
                '}';
    }
}

package com.yuwei.homework;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Test1 {
    public static void main(String[] args) throws ClassNotFoundException, IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException {
//        Class<?> fileClass = Class.forName("java.io.File");
//
//        Constructor<?>[] declaredConstructors = fileClass.getDeclaredConstructors();
//        for (Constructor<?> declaredConstructor : declaredConstructors) {
//            System.out.println(declaredConstructor);
//        }
//
//        Constructor<?> declaredConstructor = fileClass.getDeclaredConstructor(String.class);
//        Object o = declaredConstructor.newInstance("e:\\1.txt");
//
//        Method createNewFile = fileClass.getDeclaredMethod("createNewFile");
//        createNewFile.invoke(o);


    }


}

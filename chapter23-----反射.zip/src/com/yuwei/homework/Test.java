package com.yuwei.homework;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Test {
    public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InstantiationException, NoSuchFieldException, InvocationTargetException {
        Class<?> aClass = Class.forName("com.yuwei.homework.PrivateTest");
        Object o = aClass.newInstance();
        Field name = aClass.getDeclaredField("name");
        name.setAccessible(true);
        name.set(o,"hyc");
        Method method = aClass.getMethod("getName");
        Object invoke = method.invoke(o);
        System.out.println(invoke);
    }

}
class PrivateTest{
    private String name = "hello_yu_wei";

    public String getName() {
        return name;
    }
}

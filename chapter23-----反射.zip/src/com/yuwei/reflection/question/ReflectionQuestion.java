package com.yuwei.reflection.question;
import com.yuwei.Cat;

import java.io.FileInputStream;
import java.lang.reflect.Method;
import java.util.Properties;

@SuppressWarnings({"all"})
public class ReflectionQuestion {
    public static void main(String[] args) throws Exception {

//        Properties properties = new Properties();
//        properties.load(new FileInputStream("src\\yu.properties"));
//        String classfullpath = properties.get("classfullpath").toString();
//        String methodName = properties.get("method").toString();
//        System.out.println(classfullpath);
//        System.out.println(methodName);
//
//        Class aClass = Class.forName(classfullpath);
//        Object o = aClass.newInstance();
//        Method method = aClass.getMethod(methodName);
//        method.invoke(o);
//
//        Field nameField = aClass.getField("name");
//        System.out.println(nameField.get(o));
//
//        Constructor constructor = aClass.getConstructor();
//        System.out.println(classfullpath);
//
//        Constructor constructor1 = aClass.getConstructor(String.class);
//        System.out.println(constructor1);
        m1();
        m2();
        m3();

    }

    public static void m1(){
        long strat = System.currentTimeMillis();
        Cat cat = new Cat();
        for (int i = 0; i < 999999999; i++) {
            cat.hi();
        }
        long end = System.currentTimeMillis();
        System.out.println("m1() " + (end-strat));

    }

    public static void m2() throws Exception {
        Properties properties = new Properties();
        properties.load(new FileInputStream("src\\yu.properties"));
        String classfullpath = properties.get("classfullpath").toString();
        String methodName = properties.get("method").toString();
        Class aClass = Class.forName(classfullpath);
        Object o = aClass.newInstance();
        Method method = aClass.getMethod(methodName);
        long strat = System.currentTimeMillis();
        Cat cat = new Cat();
        for (int i = 0; i < 999999999; i++) {
            method.invoke(o);
        }
        long end = System.currentTimeMillis();
        System.out.println("m2() " + (end-strat));
    }

    public static void m3() throws Exception {
        Properties properties = new Properties();
        properties.load(new FileInputStream("src\\yu.properties"));
        String classfullpath = properties.get("classfullpath").toString();
        String methodName = properties.get("method").toString();
        Class aClass = Class.forName(classfullpath);
        Object o = aClass.newInstance();
        Method method = aClass.getMethod(methodName);
        method.setAccessible(true);
        long strat = System.currentTimeMillis();
        Cat cat = new Cat();
        for (int i = 0; i < 999999999; i++) {
            method.invoke(o);
        }
        long end = System.currentTimeMillis();
        System.out.println("m3() " + (end-strat));

    }
}

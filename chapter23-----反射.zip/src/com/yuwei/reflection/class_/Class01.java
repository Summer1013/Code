package com.yuwei.reflection.class_;

import com.yuwei.Car;

import java.lang.reflect.Field;

@SuppressWarnings({"all"})
public class Class01 {
    public static void main(String[] args) throws ClassNotFoundException, IllegalAccessException, InstantiationException, NoSuchFieldException {
        String classAllPath = "com.yuwei.Car";
        Class cls = Class.forName(classAllPath);

        System.out.println(cls);

        System.out.println(cls.getClass());

        System.out.println(cls.getPackage().getName());

        System.out.println(cls.getName());

        Car car = (Car)cls.newInstance();
        System.out.println(car);

        Field brand = cls.getField("brand");
        System.out.println(brand.get(car));

        brand.set(car,"兰博基尼");
        System.out.println(brand.get(car));

        Field[] fields = cls.getFields();
        for (int i = 0; i < fields.length; i++) {
            System.out.print(fields[i].get(car) + "  ");
        }

    }
}

package com.yuwei.reflection.class_;

import java.io.Serializable;
@SuppressWarnings({"all"})
public class AllTypeClass {
    public static void main(String[] args) {
        Class<String> cls1 = String.class;

        Class<Serializable> cls2 = Serializable.class;

        Class cls3 = Integer[].class;

        Class<Deprecated> cls4 = Deprecated.class;

        Class<Thread.State> cls5 = Thread.State.class;

        Class<Void> cls6 = void.class;

        Class<Long> cls7 = long.class;

        Class<Class> cls8 = Class.class;

        System.out.println(cls1);
        System.out.println(cls2);
        System.out.println(cls3);
        System.out.println(cls4);
        System.out.println(cls5);
        System.out.println(cls6);
        System.out.println(cls7);
        System.out.println(cls8);

    }
}

#如何显示每个部门的平均工资和最高工资
SELECT AVG(sal),MAX(sal) ,deptno 
	FROM emp GROUP BY deptno;#按照deptno分组
	
	
#显示每个部门的每种岗位的平均工资和最低工资
#1.显示每个部门的平均工资和最低工资
SELECT AVG(sal), MIN(sal) , deptno
	FROM emp GROUP BY deptno;
	
#2.显示每个部门的每种岗位的平均工资和最低工资
SELECT AVG(sal), MIN(sal) , deptno, job 
	FROM emp GROUP BY deptno, job;


	
#显示平均工资低于2000的部门号和它的平均工资
#1.显示各个部门的平均工资和部门号
SELECT AVG(sal), deptno 
	FROM emp GROUP BY deptno;
#2.显示各个部门的平均工资和部门号,进行过滤,选出低于2000的
SELECT AVG(sal) AS avg_sal, deptno
	FROM emp GROUP BY deptno
		HAVING avg_sal < 2000;
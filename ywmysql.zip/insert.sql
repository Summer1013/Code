CREATE TABLE `goods`(id INT, goods_name VARCHAR(10), price DOUBLE);

INSERT INTO `goods` (id,goods_name,price) VALUES(1,'华为手机',5000);
INSERT INTO `goods` (id,goods_name,price) VALUES(2,'苹果手机',6000);

SELECT * FROM `goods`;

DESC employee;

INSERT INTO `employee` VALUES(0001,'夏天','2000-10-13','2022-3-26 13:15:50','java工程师
',15000,'我很强我知道','明天办入职手续');

SELECT * FROM `employee`
#学生表
CREATE TABLE S(
	`S#` VARCHAR(10),#学生学号
	`SNAME` VARCHAR(10),#姓名
	`AGE` INT,#年龄
	`SEX` VARCHAR(10)#性别
	);
INSERT INTO S VALUES('001', '李强', 23, '男');
INSERT INTO S VALUES('002', '王强', 22, '男');
INSERT INTO S VALUES('003', '张三', 21, '男');
INSERT INTO S VALUES('004', '刘二', 24, '男');
INSERT INTO S VALUES('005', '夏天', 22, '男');

#学生课程分数表
CREATE TABLE SC(
	`S#` VARCHAR(10),#学生学号
	`C#` VARCHAR(10),#课程编号
	`SCORE` INT#课程分数
	);
INSERT INTO SC VALUES('001', 'C1', 83);	
INSERT INTO SC VALUES('001', 'C2', 90);
INSERT INTO SC VALUES('002', 'C1', 99);
INSERT INTO SC VALUES('003', 'C2', 100);

#课程信息表
CREATE TABLE C(
	`C#` VARCHAR(10),#课程编号
	`CNAME` VARCHAR(50),#课程名
	`TEACHER` VARCHAR(10)#课程老师名
	);
INSERT INTO C VALUES('C1', '数据库原理', '王华');
INSERT INTO C VALUES('C2', 'Java', '程军');

#既选修了C1，又选修了C2的学生学号
SELECT DISTINCT sc1.`S#` FROM SC sc1,SC sc2 WHERE sc1.`C#` != sc2.`C#` AND sc1.`S#` = sc2.`S#`;
#选修了程军老师所授课程之一的学生姓名
SELECT S.`SNAME`
FROM S,SC,C
WHERE SC.`C#` = C.`C#` AND SC.`S#` = S.`S#` AND C.`TEACHER` = '程军';
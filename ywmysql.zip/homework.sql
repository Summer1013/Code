SELECT ename
FROM emp
WHERE job = (SELECT job FROM emp WHERE ename = 'SCOTT') AND ename != 'SCOTT';
-------------------------------------------------------------------
SELECT *
FROM emp
WHERE sal > (SELECT MAX(sal) FROM emp WHERE deptno = 30) AND deptno != 30;
-------------------------------------------------------------------
SELECT COUNT(*), AVG(sal), deptno, AVG(DATEDIFF(NOW(),hiredate))
FROM emp
GROUP BY deptno;
-----------------------------------------------------------------
SELECT ename, dname, sal
FROM emp, dept
WHERE dept.deptno = emp.deptno;
----------------------------------------------------
SELECT COUNT(*), emp.deptno, dept.dname, dept.loc
FROM dept, emp
WHERE emp.deptno = dept.deptno
GROUP BY emp.deptno;
----------------------------------------
SELECT job, MIN(sal) FROM emp GROUP BY job;
----------------------------------------------
SELECT ename, (sal+ IFNULL(comm,0))*12 allsal FROM emp ORDER BY allsal;
---------------------------------------------------------------------------
CREATE TABLE department(
	departmentid VARCHAR(32) PRIMARY KEY,#系号
	deptname VARCHAR(32) UNIQUE NOT NULL #系名
	);
	
CREATE TABLE class(
	classid INT PRIMARY KEY,#班号
	`subject` VARCHAR(32) NOT NULL DEFAULT '',#专业名
	deptname VARCHAR(32),#系名
	enrolltime INT NOT NULL DEFAULT 2000,#入学年份
	num INT NOT NULL DEFAULT 0,#人数
	FOREIGN KEY(deptname) REFERENCES department(deptname)
	); 
	
CREATE TABLE students(
	studentid INT PRIMARY KEY,#学号
	`name` VARCHAR(32) NOT NULL DEFAULT '',#姓名
	age INT NOT NULL DEFAULT 0,#年龄
	classid INT,#班号
	FOREIGN KEY(classid) REFERENCES class(classid)
	); 
	
DROP TABLE students;

DROP TABLE class;

DROP TABLE department;

INSERT INTO department VALUES('001','数学');

INSERT INTO department VALUES('002','计算机');

INSERT INTO department VALUES('003','化学');

INSERT INTO department VALUES('004','中文');

INSERT INTO department VALUES('005','经济');

INSERT INTO class VALUES(101, '软件', '计算机', 1995, 20);

INSERT INTO class VALUES(102, '微电子', '计算机', 1996, 30);

INSERT INTO class VALUES(111, '无机化学', '化学', 1995, 29);

INSERT INTO class VALUES(112, '高分子化学', '化学', 1996, 25);

INSERT INTO class VALUES(121, '统计数学', '数学', 1995, 20);

INSERT INTO class VALUES(131, '现代语言', '中文', 1996, 20);

INSERT INTO class VALUES(141, '国际贸易', '经济', 1997, 30);

INSERT INTO class VALUES(142, '国际金融', '经济', 1996, 14);

INSERT INTO students VALUES(8101, '张三', 18, 101);

INSERT INTO students VALUES(8102, '钱四', 16, 121);

INSERT INTO students VALUES(8103, '王玲', 17, 131);

INSERT INTO students VALUES(8105, '李飞', 19, 102);

INSERT INTO students VALUES(8109, '赵四', 18, 141);

INSERT INTO students VALUES(8110, '李可', 20, 142);

INSERT INTO students VALUES(8201, '张飞', 18, 111);

INSERT INTO students VALUES(8302, '周瑜', 16, 112);

INSERT INTO students VALUES(8203, '王亮', 17, 111);

INSERT INTO students VALUES(8305, '董庆', 19, 102);

INSERT INTO students VALUES(8409, '赵龙', 18, 101);

SELECT * FROM department;

SELECT * FROM class;

SELECT * FROM students;

SELECT `name` 
FROM students 
WHERE `name` LIKE '李%';

SELECT COUNT(*) num, deptname 
FROM class 
GROUP BY deptname 
HAVING num > 1;

SELECT SUM(num) nums, deptname 
FROM class 
GROUP BY deptname 
HAVING nums >= 30;

SELECT departmentid, s.* 
FROM (SELECT SUM(num) nums, deptname FROM class GROUP BY deptname HAVING nums >= 30) s, department 
WHERE s.deptname = department.deptname;

INSERT INTO department VALUES('006','物理系');

START TRANSACTION;
UPDATE class SET num = num - 1 WHERE classid = (SELECT classid FROM students WHERE `name` = '张三');
DELETE FROM students WHERE `name` = '张三';
COMMIT;


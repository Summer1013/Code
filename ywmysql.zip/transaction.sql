 --------------------------------------------------
1.创建测试表
CREATE TABLE t00(
	id INT,
	`name` VARCHAR(32)
	);	
2.开始事务
START TRANSACTION;
3.设置保存点
SAVEPOINT a;
4.执行dml操作
INSERT INTO t00 VALUES(100, 'tom');
5.设置保存点
SAVEPOINT b;
6.执行dml操作
INSERT INTO t00 VALUES(200, 'jack');
7.回退到b
ROLLBACK TO b;
8.回退到a
ROLLBACK TO a;
9.回退到事务的开始
ROLLBACK;
10.提交事务
COMMIT;
--------------------------------------------------
1.如果不开始事务，默认情况下，dml操作是自动提交的，不能回滚。
2.如果开始一个事务，你没有创建保存点.你可以执行rollback,默认就是回退到你事务开始的状态。
3.你也可以在这个事务中(还没有提交时)，创建多个保存点比如: SAVEPOINT aaa;执行dml , SAVEPOINT bbb;。
4.你可以在事务没有提交前，选择回退到哪个保存点。
5.innodb的存储引擎支持mysql的事务机制，MyISAM不支持。
6.开始一个事务方法一：start transaction，方法二set autocommit= off。
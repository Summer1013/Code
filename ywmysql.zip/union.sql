--------------------------------------------------
SELECT ename, sal, job
FROM emp
WHERE sal > 2500
	UNION ALL
SELECT ename, sal, job
FROM emp
WHERE job = 'MANAGER'; 
UNION ALL是联合两个查找语句，不去重。
-------------------------------------------------- 
SELECT ename, sal, job
FROM emp
WHERE sal > 2500
	UNION
SELECT ename, sal, job
FROM emp
WHERE job = 'MANAGER'; 
UNION是联合两个查找语句，去重。

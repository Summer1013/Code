SELECT IF(FALSE, '北京', '上海') FROM DUAL;
#IF(1,2,3)如果1为真，则返回2，反之，返回3。
SELECT IFNULL(NULL, '上海') FROM DUAL;
#IFNULL(1,2)如果1不为NULL，则返回1，反之返回2。
SELECT CASE 
	WHEN 1 = 1 THEN 'sssss'
	WHEN 2 = 2 THEN 'aaaaaa'
	WHEN 3 = 3 THEN 'asfaf'
	ELSE 'fdfaaf' END AS 'a'
	FROM DUAL;
#结果为sssss，类似于if elseif else

SELECT ename, IF(comm IS NULL, 0.0, comm)
	FROM emp;
SELECT ename, IFNULL(comm, 0.0) 
	FROM emp;
#判断为空用IS NULL 不为空用IS NOT NULL。

SELECT ename,(SELECT CASE
		WHEN job = 'CLERK' THEN '职员'
		WHEN job = 'MANAGER' THEN '经理'
		WHEN job = 'SALESMAN' THEN '销售人员'
		ELSE job END) AS 'job', job
	FROM emp;
	
SELECT CASE
	WHEN job = 'CLERK' THEN '职员'
	WHEN job = 'MANAGER' THEN '经理'
	WHEN job = 'SALESMAN' THEN '销售人员'
	ELSE job END AS 'job'
	FROM emp;

#自连接
SELECT * 
	FROM emp worker, emp boss;
------------------------------------------------------	
SELECT 
	worker.ename AS '员工名',
	boss.ename AS '老板名'
	FROM emp worker, emp boss;
------------------------------------------------------	
SELECT 
	worker.ename AS '员工名',
	boss.ename AS '老板名'
	FROM emp worker, emp boss
	WHERE worker.mgr = boss.empno;
------------------------------------------------------------
	

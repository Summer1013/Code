#查看当前数据库服务器中所有的数据库
SHOW DATABASES
#查看前面创建的hsp_db01数据库的定义信息
SHOW CREATE DATABASE hsp_db01
#当数据库的名字与关键字相同时 可以使用反引号(在数字1左边)来区分
CREATE DATABASE `create`
CREATE DATABASE hsp_db01
DROP DATABASE `create`
DROP DATABASE hsp_db01
SELECT * FROM student
	ORDER BY math;#默认升序
	
SELECT * FROM student
	ORDER BY math DESC;#desc降序
	
SELECT `name`,(chinese + english + math) AS total_score FROM student 
	ORDER BY (chinese + english + math) DESC;
	
SELECT * FROM student 
	WHERE `name` LIKE '赵%'
	ORDER BY math;
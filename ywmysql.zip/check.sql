--------------------------------------------------
CREATE TABLE t20(
	id INT PRIMARY KEY,
	`name` VARCHAR(32),
	sex VARCHAR(6) CHECK (sex IN('man', 'woman')),
	sal DOUBLE CHECK (sal > 1000 AND sal < 2000));
INSERT INTO t20 VALUES (1, 'jack', 'mid', 1);
INSERT INTO t20 VALUES (2, 'jack', 'man', 1500);
MYSQL5.7版本中，check只做语法的校对，并不会对数据生效。
oracle，sql server，这两个数据库中也有check并且可以生效。
--------------------------------------------------
SELECT * FROM t20;

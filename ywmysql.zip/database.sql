#删除数据库
DROP DATABASE hsp_db01

#创建数据库
CREATE DATABASE hsp_db01

#创建数据库并且设置字符集
CREATE DATABASE hsp_db02 CHARACTER SET utf8

#创建数据库并且设置字符集和字符规则
CREATE DATABASE hsp_db03 CHARACTER SET utf8 COLLATE utf8_bin

#从t1表中查询所有字段name为tom的
SELECT * FROM t1 WHERE `NAME` = 'tom'

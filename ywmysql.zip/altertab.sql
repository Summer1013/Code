ALTER TABLE emp 
	ADD image VARCHAR(32) NOT NULL DEFAULT '' 
	AFTER RESUME;
#给表emp添加一个image字段不为空默认为‘’ 添加在resume字段后面	
DESC emp;
#显示表emp的结构
ALTER TABLE emp 
	MODIFY job VARCHAR(60) NOT NULL DEFAULT '';
#修改表emp中字段job的类型
ALTER TABLE emp 
	DROP sex;
#删除表emp中字段sex
RENAME TABLE emp TO employee;
#将表emp的表名修改成employee
DESC employee;
ALTER TABLE employee 
	CHARSET utf8;
#给表employee设置字符集
ALTER TABLE employee 
	CHANGE `name` `user_name` VARCHAR(32) NOT NULL DEFAULT '';
#将表employee中的字段name名改成user_name
DESC employee;

SELECT * FROM student;

SELECT `name`,english FROM student;

SELECT english FROM student;

SELECT DISTINCT english FROM student;
#distinct 查询结果所有字段都相同则去重

SELECT `name`,(chinese + english + math) FROM student;

SELECT `name`,(chinese + english + math) AS total_score FROM student;

SELECT `name` AS '名字',(chinese + english + math) AS '总分' FROM student;

SELECT * FROM student 
	WHERE `name` = '赵云';
	
SELECT `name`,`english` FROM student 
	WHERE english > 90;
	
SELECT * FROM student 
	WHERE chinese + english + math > 200;
	
SELECT * FROM student 
	WHERE english > chinese;
	
SELECT * FROM student 
	WHERE (chinese + english + math) > 200 
	AND (math < chinese) 
	AND `name` LIKE '宋%';
		
SELECT * FROM student
	WHERE english >= 80 AND english <= 90;
SELECT * FROM student
	WHERE english BETWEEN 80 AND 90;
	
SELECT * FROM student 
	WHERE math = 80 OR math = 90 OR math = 91;
SELECT * FROM student
	WHERE math IN (89, 90, 91);
	
SELECT * FROM student 
	WHERE `name` LIKE '赵%';
	
SELECT * FROM student
	WHERE math > 80 AND chinese > 80;
	
SELECT * FROM student
	WHERE chinese BETWEEN 70 AND 80;

SELECT * FROM student 
	WHERE (chinese + english + math) IN (189, 190, 191);
	
SELECT * FROM student 
	WHERE `name` LIKE '李%' OR `name` LIKE '宋%';
	
SELECT * FROM student 
	WHERE chinese = math + 45;


	

	

	
SELECT ename, emp.deptno, temp.avg_sal, sal
FROM (SELECT deptno, AVG(sal) AS avg_sal 
		FROM emp
		GROUP BY deptno) temp, emp
WHERE temp.deptno = emp.deptno 
	AND temp.avg_sal < emp.sal;
每个部门高于本部门的平均工资的人员信息
--------------------------------------------------
SELECT ename, emp.deptno, temp.max_sal 
FROM (SELECT deptno, MAX(sal) AS max_sal
	FROM emp
	GROUP BY deptno) temp, emp
WHERE temp.deptno = emp.deptno 
	AND  temp.max_sal = emp.sal;
查找每个部门工资最高的人员信息
--------------------------------------------------
SELECT dept.*, dept_num.num AS 人数
FROM dept, (SELECT deptno, COUNT(*) AS num					
		FROM emp 
		GROUP BY deptno	) dept_num
WHERE dept.deptno = dept_num.deptno;
每个部门的信息(包括：部门名，编号，地址)和人员数量
部门名,编号,地址来自dept。
--------------------------------------------------
SELECT * FROM dept;
--------------------------------------------------

--------------------------------------------------

--------------------------------------------------

--------------------------------------------------

--------------------------------------------------

	
#%代替任意字符 _代替一个字符 
SELECT * FROM emp
	WHERE ename LIKE '__i%';


SELECT * FROM emp
	ORDER BY deptno ASC, sal DESC;
	


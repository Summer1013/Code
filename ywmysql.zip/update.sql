UPDATE `employee` 
	SET `salary` = 5000;

UPDATE `employee` 
	SET `image` = 'd:nu.md' 
	WHERE id = 1; 

INSERT INTO `employee` (id) VALUES(2);

UPDATE `employee` 
	SET `salary` = 15000,
	job = 'python工程师',
	`resume` = '头都秃了能不强吗',
	user_name = '鱼尾',
	birthday = '2000-11-11',
	entry_date = '1322-10-6 16:54:13',
	image = 'c:\\my.jpg' WHERE id = 2;

UPDATE `employee` 
	SET `salary` = `salary` + 3000 
	WHERE id = 1; 



SELECT * FROM employee;



 
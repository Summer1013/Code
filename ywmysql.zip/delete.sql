DELETE FROM employee
	WHERE id = 2;
	
DELETE FROM employee;

DELETE FROM t01;
	
SELECT * FROM employee;

RENAME TABLE t1 TO t01;


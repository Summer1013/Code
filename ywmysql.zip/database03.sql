#备份hsp_db02和hsp_db03库中的数据，并恢复

#备份 在命令行中执行
mysqldump -u root -p -B hsp_db02 hsp_db03 > d:\\bak.sql

DROP DATABASE hsp_db02
DROP DATABASE hsp_db03

#恢复 进入mysql命令行中再执行
source d:\\bak.sql

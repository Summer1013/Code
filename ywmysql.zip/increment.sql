--------------------------------------------------
CREATE TABLE t21(
	id INT PRIMARY KEY AUTO_INCREMENT,
	email VARCHAR(32) NOT NULL DEFAULT '',
	`name` VARCHAR(32) NOT NULL DEFAULT ''
	);
INSERT INTO t21 VALUES(NULL, 'jack@qq.com', 'jack');
INSERT INTO t21 (email, `name`) VALUES('tom@qq.com', 'tom');
INSERT INTO t21 VALUES(999,'tom@qq.com', 'tom');
ALTER TABLE t21 AUTO_INCREMENT = 100;
1.一般来说自增长是和primary key配合使用的。
2.自增长也可以单独使用，但需要和unique一起。
3.自增长修饰的字段为整数型的（虽然小数也可以但是基本不使用）。
4.ALTER TABLE 表名 AUTO_INCREMENT = 初始值;，该初始值只能在表中没数据的时候有效。
5.直接添加的时候也可以初始值，但这个初始值可以在表中有数据时进行。
--------------------------------------------------
SELECT * FROM t21;
DELETE FROM t21;

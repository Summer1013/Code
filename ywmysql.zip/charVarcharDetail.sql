#char(4) varchar(4) 这个4代表的是字符 不是字节 不区分汉字还是字母 都是4字符
#char的4是定长 你加入的数据如果没到4字符 也会分配4个字符的内存
#varchar是边长 实际内存 = 数据的内存 + 1-3个字节记录varchar长度

CREATE TABLE t11(`nmae` CHAR(4));
INSERT INTO t11 VALUES('我我我我');
INSERT INTO t11 VALUES('aaaa');
SELECT * FROM t11;

CREATE TABLE t12(`name` VARCHAR(4));
INSERT INTO t12 VALUES('abcd');
INSERT INTO t12 VALUES('啊啊啊啊');
SELECT * FROM t12;

#如果varchar长度不够用 则使用 text mediumtext longtext

CREATE TABLE t13(content TEXT,content2 MEDIUMTEXT,content3 LONGTEXT);
INSERT INTO t13 VALUES('1啊啊啊啊啊啊啊','121是是是是是是是','3231的的的的的的的');
SELECT * FROM t13;
#bit类型使用
#BIT(m) m范围在1-64 m=8为一个字节
#数据是按照二进制显示
DROP TABLE t5#删除表t5
DROP DATABASE hsp_db01

CREATE TABLE t5(num BIT(8))#创建表t5

INSERT INTO t5 VALUES(11)#给表t5增加数据

SELECT * FROM t5#查找表t5

SELECT * FROM t5 WHERE num = 11#查找表t5中num=11的数据
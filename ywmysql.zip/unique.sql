--------------------------------------------------
CREATE TABLE t19(id INT UNIQUE NOT NULL,
		`name` VARCHAR(32),
		email VARCHAR(32));
INSERT INTO t19 VALUES(1, 'tom', 'tom@sohu.com');
INSERT INTO t19 VALUES(NULL, 'tom', 'tom@sohu.com');	
1.unique约束（唯一），被修饰的列不可以重复。
2.如果没有指定 NOT NULL 则unique字段可以有多个null。
3.一张表可以有多个unique字段。

INSERT INTO `goods` VALUES(30,'vivo',5000),(40,'oppo',6000);

INSERT INTO `goods` (id) VALUES(60);

SELECT * FROM goods
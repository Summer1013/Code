#statistics 统计学

SELECT * FROM student;

SELECT COUNT(*) FROM student;

SELECT COUNT(*) FROM student
	WHERE math > 90;
	
SELECT COUNT(*) FROM student
	WHERE (chinese + english + math) > 250;
	
CREATE TABLE t15(
	`name` VARCHAR(20));
INSERT INTO t15 VALUES('tom');
INSERT INTO t15 VALUES('jack');
INSERT INTO t15 VALUES('mary');
INSERT INTO t15 VALUES(NULL);

SELECT * FROM t15;

SELECT COUNT(*) FROM t15;#4
SELECT COUNT(`name`) FROM t15;#3 

SELECT SUM(`math`) FROM student;
SELECT SUM(`chinese`), SUM(`english`),SUM( `math`) FROM student; 
SELECT SUM(`chinese` + `english` + `math`) FROM student;
SELECT SUM(`chinese`)/COUNT(*) FROM student;

SELECT AVG(math) FROM student;
SELECT MIN(math),MAX(math) FROM student;
SELECT MAX(math) FROM student;



	

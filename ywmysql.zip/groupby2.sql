SELECT COUNT(*), COUNT(comm) FROM emp;
	
SELECT COUNT(*), AVG(sal), job FROM emp GROUP BY job;
#COUNT(列) 如果该列有值为NULL，则不统计该值

SELECT COUNT(DISTINCT mgr) AS '经理人数' FROM emp;

SELECT deptno, AVG(sal) AS avg_sal
	FROM emp
	GROUP BY deptno
	HAVING avg_sal > 1000
	ORDER BY avg_sal DESC
	LIMIT 0, 2;
#顺序GROUP BY, HAVING, RODER BY, LIMIT

 
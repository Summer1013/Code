#讲解整形tinyint范围
#unsigned修饰 （-128 - 127） 默认则是（0 - 255）
#如果没有使用unsigned修饰tinyint   tinyint则就是有符号修饰

CREATE TABLE t3(id TINYINT);#创建一个t3表

INSERT INTO t3 VALUES(122)#给t3表添加数据

SELECT * FROM t3;#查找t3表

CREATE TABLE t4(id TINYINT UNSIGNED);#创建一个t4表

INSERT INTO t4 VALUES(1)#给t4表添加数据



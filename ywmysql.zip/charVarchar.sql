#注释的快捷键 shift + ctrl + c
#解除注释的快捷键 shift + ctrl + r
#char(size) 固定长度字符串 size(0 - 255字符)
#varchar(size) 可变长度字符串 size(0 - 65535字节)
#utf8编码中最大(65535-3)/3=21844字符 1-3个字节用于记录大小
#utf8 varchar(size) size = (65535-3)/3 = 21844
#gbk  varchar(size) size = (65535-3)/2 = 32766

CREATE TABLE t8(`name` CHAR(255))

CREATE TABLE t9(`name` VARCHAR(21844))

CREATE TABLE t10(`name` VARCHAR(32766)) CHARACTER SET gbk




SELECT * FROM emp, dept;

SELECT * FROM dept, emp;
	
SELECT * FROM emp, salgrade;
	
SELECT * FROM salgrade, emp;
	
SELECT * FROM salgrade, dept;
	
SELECT * FROM dept, salgrade;

SELECT * FROM emp, dept
	WHERE emp.deptno = dept.deptno;

SELECT ename, sal, dname, emp.deptno
	FROM emp, dept
	WHERE emp.deptno = dept.deptno;
	
SELECT ename, sal, dname, emp.deptno
	FROM emp, dept
	WHERE emp.deptno = dept.deptno AND emp.deptno = 10;

SELECT *
	FROM emp, salgrade
	WHERE sal >= losal AND sal <= hisal;
SELECT *
	FROM emp, salgrade
	WHERE sal BETWEEN losal AND hisal;
#默认情况下：当两张表查询时：
#1.从行数多的表中，取出一行和行数短的表进行组合
#2.一共返回的行数是第一张表行数*第二张表的行数，列数则是第一张表的列 + 第二张表的列
#3.这样处理多表查询的结果叫做笛卡尔集
#4.解决这个多表查询的关键就在于WHERE的使用
#5.多表查询的条件必须不少于表数-1
#6.如果两个表有相同的字段则需要使用表名.字段
--------------------------------------------------
CREATE TABLE my_class(
	id INT PRIMARY KEY,
	`name` VARCHAR(32) NOT NULL DEFAULT '',
	`add` VARCHAR(32) NOT NULL DEFAULT '');
INSERT INTO my_class VALUES(100, 'java01', '北京');
INSERT INTO my_class VALUES(200, 'web2', '上海');
INSERT INTO my_class VALUES(300, 'python', '南昌');
CREATE TABLE my_stu(
	id INT,
	`name` VARCHAR(32) NOT NULL DEFAULT '',
	class_id INT,
	FOREIGN KEY (class_id) REFERENCES my_class(id));
INSERT INTO my_stu VALUES(1, '鱼尾', 100);
INSERT INTO my_stu VALUES(2, '于伟', 200);
INSERT INTO my_stu VALUES(3, 'tom', 300);
INSERT INTO my_stu VALUES(4, 'jack', 400);
无法添加，外键值在主键中没有对应的数据。
INSERT INTO my_stu VALUES(4, 'jack', NULL);		
用与定义主表和从表之间的关系：外键约束要定义在从表上，主表则必须
具有主键约束或是unique约束，当定义外键约束后，要求外键列数据必须
在主表的主键列存在或是为null。
外键所指向表的字段必须是primary key或者unique。
表的引擎是innodb才支持主键。
外键字段的类型要和主键字段的类型一致（长度可以不同）。
外键字段的值，必须在主键字段中出现过，或者为null，前提是外键字段允许为null。
一旦建立主外键关系数据不能随意删除了，如果需要删除，则先删除外键。

#float 保留小数点后4位
#double 保留小数点后14位
#decimal(D,M)D最大65，M最大30 ,M是小数位数的总数，D是小数点后面的位数
#decimal(D,M)如果D被省略默认是0，如果D是0则没有后面的小数部分，如果M被省略默认是10  
#如果使用的小数精度很高或者数要非常大则使用decimal

DROP TABLE t6;

CREATE TABLE t6(num1 FLOAT,num2 DOUBLE,num3 DECIMAL(30,20));

INSERT INTO t6 VALUES(88.123456789123456,88.123456789123456,88.123456789123456);

SELECT * FROM t6;
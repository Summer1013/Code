--------------------------------------------------
CREATE TABLE my_tab01(id INT,
			`name` VARCHAR(32),
			sal DOUBLE,
			job VARCHAR(32),
			deptno INT);
--------------------------------------------------
DESC my_tab01;
--------------------------------------------------
INSERT INTO my_tab01(id, `name`, sal, job, deptno)
SELECT empno, ename, sal, job, deptno
FROM emp;
将表emp中的数据复制到表my_tab01中，字段需要一一对齐。
--------------------------------------------------
SELECT * 
FROM my_tab01;
--------------------------------------------------
INSERT INTO my_tab01
SELECT * 
FROM my_tab01;
自我复制。
--------------------------------------------------
CREATE TABLE my_tab02 
LIKE emp;
创建一个表my_tab02结构像表emp一样。
--------------------------------------------------
INSERT INTO my_tab02
SELECT *
FROM emp;
--------------------------------------------------
CREATE TABLE my_temp 
LIKE my_tab02;
1.创建一个像表my_tab02的临时表my_temp。
INSERT INTO my_temp
SELECT DISTINCT *
FROM my_tab02;
2.将去重的表my_tab02数据添加到临时表my_temp中。
DELETE FROM my_tab02;
3.将表my_tab02中的数据清空。
INSERT INTO my_tab02
SELECT *
FROM my_temp;
4.将临时表的数据添加到空表my_tab02中。
DROP TABLE my_temp;
5.删除临时表。
--------------------------------------------------
SELECT *
FROM my_tab02;

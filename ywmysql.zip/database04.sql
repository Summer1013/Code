#创建表
#字符集character 校验 collate 引擎 engine
CREATE TABLE `user` (
	id INT,
	`name` VARCHAR(255),
	`password` VARCHAR(255),
	`birthday` DATE)
CHARSET utf8 COLLATE utf8_bin ENGINE INNODB
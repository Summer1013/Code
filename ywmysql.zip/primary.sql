--------------------------------------------------------
约束用于确保数据库的数据满足特定的商业规则。
在mysql中，约束包括：not null，unique，primary key，foreign key，check五种
--------------------------------------------------
主键primary key的使用
--------------------------------------------------
CREATE TABLE t16(id INT,
		`name` VARCHAR(32),
		email VARCHAR(32),
		PRIMARY KEY (id));	
CREATE TABLE t17(id INT PRIMARY KEY,
		`name` VARCHAR(32),
		email VARCHAR(32));	
CREATE TABLE t18
	(id INT,
	`name` VARCHAR(32),
	email VARCHAR(32),
	PRIMARY KEY (id, `name`)
	);
DESC t17;
DESC t18;
1.主键列的值不能重复。
2.主键的值不能为空。
3.主键可以在创建表的字段定义，也可以在创建表的结尾定义。
4.一张表最多只有一个主键但是可以有复合主键（比如id+name）,代表将id和name整体堪称主键。
5.使用desc 表名，可以看到primary key的情况，搜索出来的key值中有PRI就代表主键。

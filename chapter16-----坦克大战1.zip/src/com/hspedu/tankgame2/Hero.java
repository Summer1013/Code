package com.hspedu.tankgame2;

/**
 * @author 韩顺平
 * @version 1.0
 * 自己的坦克
 */
public class Hero extends Tank {
    public Hero(int x, int y) {
        super(x, y);
    }
}

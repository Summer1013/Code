package java.util;

/**
 * @author 韩顺平
 * @version 1.0
 */
public interface Map {
}

package com.yuwei.lesson01;



import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

//流式布局
public class TestFlowLayout {
    public static void main(String[] args) {
        Frame frame = new Frame();

        //流式布局，默认为中
        //frame.setLayout(new FlowLayout(FlowLayout.CENTER));

        //将流式布局设置为左
        //frame.setLayout(new FlowLayout(FlowLayout.LEFT));

        //将流式布局设置为右
        frame.setLayout(new FlowLayout(FlowLayout.RIGHT));
        frame.setBounds(100,100,500,600);

        //三个按钮
        Button button1 = new Button("1");
        Button button2 = new Button("2");
        Button button3 = new Button("3");
        frame.add(button1);
        frame.add(button2);
        frame.add(button3);
        frame.setVisible(true);

        //窗口监听，使用了23种设计模式中的适配器模式
        frame.addWindowListener(new WindowAdapter() {
            @Override
            //如果点击窗口的 × ，则调用此方法
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}

package com.yuwei.lesson01;

import java.awt.*;
//东南西北布局和表格布局
public class LayoutExercise {
    public static void main(String[] args) {
        Frame frame = new Frame();

        frame.setBounds(500,800,1000,800);
        frame.setVisible(true);
        frame.setBackground(Color.yellow);

        //给窗口大小设置为不可变
        //frame.setResizable(false);

        //给框架设置表格布局，两行一列
        frame.setLayout(new GridLayout(2,1));

        //给面板p1设置东西南北中布局
        Panel p1 = new Panel(new BorderLayout());
        Panel p2 = new Panel(new GridLayout(2,1));
        Panel p3 = new Panel(new BorderLayout());
        Panel p4 = new Panel(new GridLayout(2,2));

        //给面板p1增加按钮，并且指定按钮在面板的位置
        p1.add(new Button("East"),BorderLayout.EAST);
        p1.add(new Button("West"),BorderLayout.WEST);

        p2.add(new Button("1"));
        p2.add(new Button("2"));

        p1.add(p2,BorderLayout.CENTER);

        p3.add(new Button("East"),BorderLayout.EAST);
        p3.add(new Button("West"),BorderLayout.WEST);

        p4.add(new Button("3"));
        p4.add(new Button("4"));
        p4.add(new Button("5"));
        p4.add(new Button("6"));

        p3.add(p4,BorderLayout.CENTER);

        frame.add(p1);
        frame.add(p3);
    }
}

package com.yuwei.lesson01;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TestPanel {
    public static void main(String[] args) {
        //Panel是一个相对在Frame的窗口，不能单独存在
        Frame frame = new Frame();
        Panel panel = new Panel();

        //设置一个布局
        frame.setLayout(null);

        //给Frame设置
        frame.setBounds(800,500,300,300);
        frame.setBackground(Color.red);
        frame.setResizable(false);

        //给Panel设置
        panel.setBounds(100,100,100,100);
        panel.setBackground(Color.green);
        panel.setVisible(true);

        //将Panel加入到Frame中
        frame.add(panel);

        //将Frame可视化
        frame.setVisible(true);

        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}

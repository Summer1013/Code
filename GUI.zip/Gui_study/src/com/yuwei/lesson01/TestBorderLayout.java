package com.yuwei.lesson01;

import java.awt.*;
//东南西北中布局
public class TestBorderLayout {
    public static void main(String[] args) {
        Frame frame = new Frame();
        frame.setBounds(100, 100, 500, 500);

        Button East = new Button("East");
        Button Wast = new Button("Wast");
        Button South = new Button("South");
        Button North = new Button("North");
        Button Center = new Button("Center");

        frame.add(East,BorderLayout.EAST);
        frame.add(Wast,BorderLayout.WEST);
        frame.add(South,BorderLayout.SOUTH);
        frame.add(North,BorderLayout.NORTH);
        frame.add(Center,BorderLayout.CENTER);

        frame.setVisible(true);
    }
}

package com.yuwei.lesson01;

import java.awt.*;

//GUI的第一个界面
public class TestFrame {
    public static void main(String[] args) {
        //创建一个窗口并给一个标题名
        Frame frame = new Frame("我的第一个Java图像界面窗口");

        //设置可见性
        frame.setVisible(true);

        //设置窗口大小
        frame.setSize(400,400);

        //设置背景颜色
        frame.setBackground(Color.pink);
        //frame.setBackground(new Color(1,1,1));

        //设置窗口初始位置
        frame.setLocation(0,0);

        //设置窗口大小不可变
        frame.setResizable(false);
    }
}

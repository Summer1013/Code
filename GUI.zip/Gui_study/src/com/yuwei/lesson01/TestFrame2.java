package com.yuwei.lesson01;

import java.awt.*;

public class TestFrame2 {
    public static void main(String[] args) {
        new MyFrame(0, 0, 300, 300, Color.red);
        new MyFrame(300, 0, 300, 300, Color.black);
        new MyFrame(0, 300, 300, 300, Color.blue);
        new MyFrame(300, 300, 300, 300, Color.yellow);
    }
}

class MyFrame extends Frame {
    static int frameNums = 0;

    public MyFrame(int x, int y, int w, int h, Color color){
        super("MyFrame " + (frameNums++));
        //setLocation(x, y);
        //setSize(w, h);
        setBounds(x, y, w, h);//该方法包括了setLocation(x, y)和setSize(w, h)
        setBackground(color);
        setVisible(true);
        setResizable(false);
    }
}


package com.yuwei.lesson02;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TestText01 {
    public static void main(String[] args) {
        closeFrame(new MyFrame());
    }
    public static void closeFrame(Frame frame){
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}

class MyFrame extends Frame{
    public MyFrame(){
        //Frame frame = new Frame();
        TextField textField = new TextField();
        textField.setEchoChar('*');
        textField.addActionListener(new MyActionListener());
        add(textField);
        pack();
        setVisible(true);
    }
}

class MyActionListener implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent e) {
        TextField textField = (TextField) e.getSource();
        System.out.println(textField.getText());
        textField.setText("");
    }
}

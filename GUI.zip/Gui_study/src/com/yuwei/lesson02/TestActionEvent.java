package com.yuwei.lesson02;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TestActionEvent {
    public static void main(String[] args) {
        Frame frame = new Frame();
        Button button = new Button();

        frame.setBounds(500,500,500,500);
        frame.setBackground(Color.red);
        frame.setVisible(true);

        MyAction myAction = new MyAction();
        button.addActionListener(myAction);
        button.setBounds(700,700,100,100);
        button.setVisible(true);

        frame.add(button);

        closeFrame(frame);
    }

    public static void closeFrame(Frame frame){
        frame.addWindowListener(
                //匿名内部类，窗口监听
                new WindowAdapter() {
                    @Override
                    public void windowClosing(WindowEvent e) {
                        System.exit(0);
                    }
                });
    }
}
class MyAction implements ActionListener{
    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("你点击了这个按钮");
    }
}

package com.yuwei.lesson02;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TestActionEvent2 {
    public static void main(String[] args) {
        Frame frame = new Frame();
        frame.setBounds(500,500,500,500);
        frame.setBackground(Color.red);
        frame.setVisible(true);

        Button button1 = new Button("gameStart");
        Button button2 = new Button("gameOver");

        MyMonitor myMonitor = new MyMonitor();
        button1.addActionListener(myMonitor);
        button2.addActionListener(myMonitor);

        frame.add(button1,BorderLayout.WEST);
        frame.add(button2,BorderLayout.EAST);

        closeFrame(frame);
    }

    public static void closeFrame(Frame frame){
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}
class MyMonitor implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getActionCommand().equals("开始游戏")){
            System.out.println("游戏开始");
        }else if (e.getActionCommand().equals("结束游戏")){
            System.out.println("游戏结束");
        }else {
            System.out.println("你点错了吧");
        }
    }
}

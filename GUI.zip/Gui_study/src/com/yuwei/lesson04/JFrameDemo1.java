package com.yuwei.lesson04;

import javax.swing.*;
import java.awt.*;

public class JFrameDemo1 {
    public static void main(String[] args) {
        new JFrameDemo1().init();
    }

    public void init(){
        JFrame jFrame = new JFrame("夏天");
        jFrame.setBounds(100,100,500,500);
        jFrame.setVisible(true);
        JLabel label = new JLabel("夏天夏天");
        jFrame.add(label);
        Container contentPane = jFrame.getContentPane();
        contentPane.setBackground(Color.blue);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
}

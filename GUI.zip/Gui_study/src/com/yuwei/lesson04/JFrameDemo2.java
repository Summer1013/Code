package com.yuwei.lesson04;

import javax.swing.*;
import java.awt.*;

public class JFrameDemo2 {
    public static void main(String[] args) {
        new MyJFrame01().init();
    }
}
class MyJFrame01 extends JFrame{
    public void init(){
        this.setVisible(true);
        this.setBounds(0,0,500,500);

        JLabel label = new JLabel("Summer");
        this.add(label);

        //将标签居中
        label.setHorizontalAlignment(SwingConstants.CENTER);

        Container container = this.getContentPane();
        container.setBackground(Color.blue);

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
}

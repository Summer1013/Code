package com.yuwei.lesson04;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DialogDemo1 extends JFrame {
    public static void main(String[] args) {
        new DialogDemo1();
    }

    public DialogDemo1(){
        this.setBounds(100,100,500,500);
        this.setVisible(true);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        Container container = this.getContentPane();
        //container.setLayout(null);

        JButton jButton = new JButton("点我有惊喜哟");
        jButton.setBounds(100,100,100,100);
        jButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new MyDialog1();
            }
        });


        container.add(jButton);


    }
}
class MyDialog1 extends JDialog{
    //JDialog弹窗类
    public MyDialog1(){
        setTitle("惊不惊喜，意不意外");
        setBounds(500,500,500,500);
        setVisible(true);
        Container container = this.getContentPane();
        container.setLayout(null);
        JLabel label = new JLabel("Hello World!");
        label.setBounds(100,100,100,100);
        container.add(label);

    }
}

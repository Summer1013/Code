package com.yuwei.lesson04;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

public class IconDemo2 extends JFrame{
    public static void main(String[] args) {
        new IconDemo2();
    }

    public IconDemo2() {

        //URL url = IconDemo2.class.getResource("1.png");
        //System.out.println(url);//null
        //直接通过全路径读取-》成功
        ImageIcon imageIcon = new ImageIcon("F:\\截图\\JDBCAPI.png");

        JLabel label = new JLabel("adsada");
        label.setIcon(imageIcon);
        label.setHorizontalAlignment(SwingConstants.CENTER);

        Container container = getContentPane();
        container.add(label);

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setBounds(0,0,500,500);
        setVisible(true);
    }
}

package com.yuwei.lesson05;

import javax.swing.*;
import java.awt.*;

public class JButtonDemo extends JFrame {
    public static void main(String[] args) {
        new JButtonDemo();
    }

    public JButtonDemo(){
        Container container = this.getContentPane();

        //JButtonDemo.class.getResource("文件名")放在该包中  可以得到文件的全路径

        //里面传入一个全路径，返回一个图片图标，可以将图标加入到按钮或标签等
        ImageIcon imageIcon = new ImageIcon("F:\\截图\\JDBCAPI.png");

        JButton jButton = new JButton();

        //将图标加入到按钮中
        jButton.setIcon(imageIcon);

        //将鼠标放在图片上，会显示出   把鼠标拿开
        jButton.setToolTipText("把鼠标拿开！！！");

        container.add(jButton);

        this.setVisible(true);
        this.setBounds(0,0,500,500);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
}

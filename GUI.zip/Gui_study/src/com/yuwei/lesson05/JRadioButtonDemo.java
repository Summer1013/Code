package com.yuwei.lesson05;

import  javax.swing.*;
import java.awt.*;

public class JRadioButtonDemo extends JFrame {
    public static void main(String[] args) {
        new JRadioButtonDemo();
    }

    public JRadioButtonDemo(){
        Container container = this.getContentPane();

        //单选按钮
        JRadioButton jRadioButton1 = new JRadioButton("jRadioButton1");
        JRadioButton jRadioButton2 = new JRadioButton("jRadioButton2");
        JRadioButton jRadioButton3 = new JRadioButton("jRadioButton3");

        //按钮组，如果将按钮组去掉，则会变成复选按钮
        ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(jRadioButton1);
        buttonGroup.add(jRadioButton2);
        buttonGroup.add(jRadioButton3);

        container.add(jRadioButton1,BorderLayout.CENTER);
        container.add(jRadioButton2,BorderLayout.SOUTH);
        container.add(jRadioButton3,BorderLayout.NORTH);

        this.setVisible(true);
        this.setBounds(0,0,500,500);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
}

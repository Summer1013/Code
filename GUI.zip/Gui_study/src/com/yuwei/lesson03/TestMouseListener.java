package com.yuwei.lesson03;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Iterator;

public class TestMouseListener {
    public static void main(String[] args) {
        new MyFrame("画点");
    }
}
class MyFrame extends Frame{
    ArrayList points = new ArrayList();

    public MyFrame(String title){
        super(title);
        setBounds(0,0,1000,800);
        addMouseListener(new MyMouseListener());
        setVisible(true);
    }

    @Override
    public void paint(Graphics g) {
        Iterator iterator = points.iterator();
        while (iterator.hasNext()){
            Point point = (Point) iterator.next();
            g.fillOval(point.x,point.y,10,10);
            g.setColor(Color.blue);
        }

    }

    class MyMouseListener extends MouseAdapter{
        @Override
        public void mousePressed(MouseEvent e) {
            points.add(new Point(e.getX(),e.getY()));
            repaint();
        }
    }
}

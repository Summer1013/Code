package com.yuwei.lesson03;

import java.awt.*;

public class TestPaint {
    public static void main(String[] args) {
       new MyPaint().loadFrame();
    }
}
class MyPaint extends Frame{
    public void loadFrame(){
        setBounds(500,500,1000,800);
        setVisible(true);
    }

    @Override
    public void paint(Graphics g) {
        //super.paint(g);
        g.setColor(Color.green);
        //g.drawOval(100,100,500,500);
        g.fillOval(0,0,1000,500);
    }
}

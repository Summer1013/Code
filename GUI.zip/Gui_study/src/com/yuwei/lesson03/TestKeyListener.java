package com.yuwei.lesson03;

import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class TestKeyListener {
    public static void main(String[] args) {
        new MyKeyListener();
    }
}

class MyKeyListener extends Frame{
    public MyKeyListener(){
        setBackground(Color.CYAN);
        setBounds(0,0,100,100);
        setVisible(true);

        addKeyListener(
                new KeyAdapter() {
                    @Override
                    public void keyPressed(KeyEvent e) {
                        int keyCode = e.getKeyCode();
                        if(keyCode == KeyEvent.VK_UP){
                            System.out.println(keyCode);
                        }
                    }
                }
        );
    }
}

package com.yuwei.lesson03;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TestWindowListener {
    public static void main(String[] args) {
        new MyWindowListener();
    }
}
class MyWindowListener extends Frame{
    public MyWindowListener(){
        setBounds(0,0,1000,1000);
        setBackground(Color.red);
        setVisible(true);

        this.addWindowListener(
                //匿名内部类
                new WindowAdapter() {
                    @Override
                    public void windowClosing(WindowEvent e) {
                        System.exit(0);
                    }

                    @Override
                    public void windowActivated(WindowEvent e) {
                        MyWindowListener myWindowListener = (MyWindowListener) e.getSource();
                        myWindowListener.setTitle("你激活了该窗口");
                    }
                }
        );
    }

}

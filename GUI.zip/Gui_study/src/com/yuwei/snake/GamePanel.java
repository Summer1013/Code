package com.yuwei.snake;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

//游戏面板
public class GamePanel extends JPanel implements KeyListener, ActionListener {

    //定义蛇的数据结构
    int length;//蛇的长度
    int[] snakeX = new int[600];//蛇的x坐标
    int[] snakeY = new int[500];//蛇的y坐标
    boolean isStart;//游戏状态，默认为不开始游戏
    String str;//蛇的放下
    int score;//分数
    int foodX;//食物的x坐标
    int foodY;//食物的y坐标
    Random random = new Random();//随机数，用来生成食物
    boolean isFail;//用来判断是否失败，默认为成功
    Timer timer = new Timer(200,this);//定时器  100毫秒执行一次

    public GamePanel() {
        init();
        this.setFocusable(true);//获取焦点事件
        this.addKeyListener(this);//获取监听事件
        timer.start();//定时器开始
    }

    //初始化
    public void init(){
        length = 3;//初始化蛇的长度
        snakeX[0] = 100; snakeY[0] = 100;//初始化蛇头坐标
        snakeX[1] = 75; snakeY[1] = 100;//初始化蛇的第一节身体坐标
        snakeX[2] = 50; snakeY[2] = 100;//初始化蛇的第二节身体坐标
        str = "right";//初始化开始蛇的方向
        foodX = 25 + 25*random.nextInt(34);//初始化食物的x坐标
        foodY = 75 + 25*random.nextInt(24);//初始化食物的y坐标
        isStart  = false;//初始化开始游戏标志
        isFail = false;//初始化游戏失败标志
        score = 0;//初始化分数

    }


    //绘制面板,我们游戏中所有的东西，都是用这个画笔来画
    @Override
    protected void paintComponent(Graphics g) {
        //清屏
        super.paintComponent(g);

        //设置面板背景颜色
        this.setBackground(Color.white);

        //绘制头部广告栏
        DateCenter.header.paintIcon(this,g,25,11);

        //绘制游戏界面
        g.fillRect(25,75,850,600);

        //绘制游戏积分和蛇的长度
        g.setColor(Color.black);
        g.setFont(new Font("微软雅黑",Font.BOLD,18));
        g.drawString("分数:" + score,750,35);
        g.drawString("长度:" + length,750,55);

        //画食物
        DateCenter.food.paintIcon(this,g,foodX,foodY);

        //绘制静态小蛇的蛇头方向
        if (str.equals("right")){//蛇头向右
            DateCenter.right.paintIcon(this,g,snakeX[0],snakeY[0]);
        }else if (str.equals("left")){//蛇头向左
            DateCenter.left.paintIcon(this,g,snakeX[0],snakeY[0]);
        }else if (str.equals("up")){//蛇头向上
            DateCenter.up.paintIcon(this,g,snakeX[0],snakeY[0]);
        }else if (str.equals("down")){//蛇头向下
            DateCenter.down.paintIcon(this,g,snakeX[0],snakeY[0]);
        }
        for (int i = 1; i < length; i++) {//蛇的身体
            DateCenter.body.paintIcon(this,g,snakeX[i],snakeY[i]);
        }

        //游戏开始提示
        if(!isStart){
            g.setColor(Color.white);
            g.setFont(new Font("微软雅黑",Font.BOLD,40));
            g.drawString("按下空格开始游戏！",300,300);
        }

        //游戏失败提示
        if(isFail == true){
            g.setColor(Color.red);
            g.setFont(new Font("微软雅黑",Font.BOLD,20));
            g.drawString("你咬到自己尾巴了，游戏失败，按下空格重新开始！",300,300);
        }
    }


    //键盘监听事件
    @Override
    public void keyPressed(KeyEvent e) {
        int keyCode = e.getKeyCode();//读取你按下的键盘
        //如果按下的是空格，则表示开始或结束
        if(keyCode == KeyEvent.VK_SPACE){
            if(!isFail) {
                isStart = !isStart;
            }else {
                init();
            }
            repaint();
        }
        //小蛇移动
        if(keyCode == KeyEvent.VK_W){
            str = "up";
            repaint();
        }else if(keyCode == KeyEvent.VK_S){
            str = "down";
            repaint();
        }else if(keyCode == KeyEvent.VK_A){
            str = "left";
            repaint();
        }else if(keyCode == KeyEvent.VK_D){
            str = "right";
            repaint();
        }
    }
    //事件监听----需要通过固定事件来刷新，1s 10次
    @Override
    public void actionPerformed(ActionEvent e) {
        if(isStart && isFail == false){//如果游戏为开始状态,并且不为失败状态，则让小蛇动起来
            //吃食物
            if(snakeX[0] == foodX && snakeY[0] == foodY){
                length++;
                score += 10;
                foodX = 25 + 25*random.nextInt(34);
                foodY = 75 + 25*random.nextInt(24);
            }

            //小蛇身体移动，后一节变成前一节即可
            for (int i = length - 1; i > 0; i--) {
                snakeX[i] = snakeX[i-1];
                snakeY[i] = snakeY[i-1];
            }

            //头向右移动
            if(str.equals("right")){
                snakeX[0] = snakeX[0] + 25;
                //边界判断
                if(snakeX[0] > 850){
                    snakeX[0] = 25;
                }
            }else if(str.equals("left")){//头向左移动
                snakeX[0] = snakeX[0] - 25;
                //边界判断
                if(snakeX[0] < 25){
                    snakeX[0] = 850;
                }
            }else if(str.equals("up")){//头向上移动
                snakeY[0] = snakeY[0] - 25;
                //边界判断
                if(snakeY[0] < 75){
                    snakeY[0] = 650;
                }
            }else if(str.equals("down")){//头向下移动
                snakeY[0] = snakeY[0] + 25;
                //边界判断
                if(snakeY[0] > 650){
                    snakeY[0] = 75;
                }
            }
            for (int i = 1; i < length; i++) {
                if(snakeX[0] == snakeX[i] && snakeY[0] == snakeY[i]){
                    isFail = true;
                }
            }
            repaint();
        }
        timer.start();
    }
    @Override
    public void keyTyped(KeyEvent e) {}
    @Override
    public void keyReleased(KeyEvent e) {}
}

package com.yuwei.snake;

import javax.swing.*;
import java.net.URL;

//数据中心，存放素材
public class DateCenter {
    public static URL headerURL = DateCenter.class.getResource("statics/header.png");
    public static ImageIcon header = new ImageIcon(headerURL);

    public static URL bodyURL = DateCenter.class.getResource("statics/body.png");
    public static ImageIcon body = new ImageIcon(bodyURL);

    public static URL foodURL = DateCenter.class.getResource("statics/food.png");
    public static ImageIcon food = new ImageIcon(foodURL);

    public static URL leftURL = DateCenter.class.getResource("statics/left.png");
    public static ImageIcon left = new ImageIcon(leftURL);

    public static URL rightURL = DateCenter.class.getResource("statics/right.png");
    public static ImageIcon right = new ImageIcon(rightURL);

    public static URL upURL = DateCenter.class.getResource("statics/up.png");
    public static ImageIcon up = new ImageIcon(upURL);

    public static URL downURL = DateCenter.class.getResource("statics/down.png");
    public static ImageIcon down = new ImageIcon(downURL);


}

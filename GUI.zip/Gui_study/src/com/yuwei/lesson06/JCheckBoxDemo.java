package com.yuwei.lesson06;

import javax.swing.*;
import java.awt.*;

public class JCheckBoxDemo extends JFrame {
    public static void main(String[] args) {
        new JCheckBoxDemo();
    }

    public JCheckBoxDemo(){
        Container container = this.getContentPane();

        JCheckBox jCheckBox1 = new JCheckBox("jCheckBox1");
        JCheckBox jCheckBox2 = new JCheckBox("jCheckBox2");
        JCheckBox jCheckBox3 = new JCheckBox("jCheckBox3");

        container.add(jCheckBox1,BorderLayout.NORTH);
        container.add(jCheckBox2,BorderLayout.SOUTH);
        container.add(jCheckBox3,BorderLayout.CENTER);

        this.setVisible(true);
        this.setBounds(0,0,500,500);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
}

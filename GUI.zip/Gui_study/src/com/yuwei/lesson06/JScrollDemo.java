package com.yuwei.lesson06;

import javax.swing.*;
import java.awt.*;

public class JScrollDemo extends JFrame {
    public static void main(String[] args) {
        new JScrollDemo();
    }

    public JScrollDemo() {
        JTextArea jTextArea = new JTextArea(20,33);
        jTextArea.setText("夏天");

        //滚动框
        JScrollPane jScrollPane = new JScrollPane(jTextArea);

        Container container = this.getContentPane();
        container.add(jScrollPane);

        this.setVisible(true);
        this.setBounds(100,100,500,500);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

    }
}

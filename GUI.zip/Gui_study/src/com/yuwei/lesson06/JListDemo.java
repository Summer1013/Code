package com.yuwei.lesson06;

import javax.swing.*;
import java.awt.*;

public class JListDemo extends JFrame {
    public static void main(String[] args) {
        new JListDemo();
    }

    public JListDemo(){
        Container container = this.getContentPane();

        String[] strs = {"1","2","3","4","5","6"};
        //列表，类似于QQ好友列表
        JList jList = new JList(strs);

        container.add(jList);

        this.setVisible(true);
        this.setBounds(0,0,500,500);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
}

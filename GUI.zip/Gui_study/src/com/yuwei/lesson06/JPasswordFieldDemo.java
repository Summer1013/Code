package com.yuwei.lesson06;

import javax.swing.*;
import java.awt.*;

public class JPasswordFieldDemo extends JFrame {

    public static void main(String[] args) {
        new JPasswordFieldDemo();
    }

    public JPasswordFieldDemo(){
        Container container = this.getContentPane();

        //密码框，可以隐藏输入的字符
        JPasswordField jPasswordField1 = new JPasswordField();
        //设置隐藏后字符的样式
        jPasswordField1.setEchoChar('1');

        container.add(jPasswordField1);

        this.setVisible(true);
        this.setBounds(0,0,500,500);
        //可以直接关闭窗口
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
}

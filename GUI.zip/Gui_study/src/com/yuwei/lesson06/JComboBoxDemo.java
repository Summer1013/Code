package com.yuwei.lesson06;

import javax.swing.*;
import java.awt.*;

public class JComboBoxDemo extends JFrame {
    public static void main(String[] args) {
        new JComboBoxDemo();
    }

    public JComboBoxDemo() {
        Container container = this.getContentPane();

        //下拉列表
        JComboBox jComboBox = new JComboBox();

        jComboBox.addItem("北京");
        jComboBox.addItem("深圳");
        jComboBox.addItem("上海");
        jComboBox.addItem("杭州");

        container.add(jComboBox);

        this.setVisible(true);
        this.setBounds(0,0,100,100);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
}

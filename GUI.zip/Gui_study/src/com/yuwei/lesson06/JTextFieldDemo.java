package com.yuwei.lesson06;

import javax.swing.*;
import java.awt.*;

public class JTextFieldDemo extends JFrame {
    public static void main(String[] args) {
        new JTextFieldDemo();
    }

    public JTextFieldDemo(){
        //容器
        Container container = this.getContentPane();

        //文本框
        JTextField jTextField1 = new JTextField("hello",20);
        JTextField jTextField2 = new JTextField("world",20);

        container.add(jTextField1,BorderLayout.NORTH);
        container.add(jTextField2,BorderLayout.SOUTH);

        this.setVisible(true);
        this.setBounds(0,0,500,500);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
}

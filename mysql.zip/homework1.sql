-- homework01.sql
SELECT ename,sal*12 AS "Annual Salary" FROM emp
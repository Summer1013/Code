//Java编写步骤
1. 编写java的源代码
2. javac 编译 ,得到对应的 .class 字节码文件
3. java 运行, 本质就是把 .class 加载到jvm  运行
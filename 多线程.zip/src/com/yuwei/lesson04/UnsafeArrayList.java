package com.yuwei.lesson04;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.CopyOnWriteArrayList;

public class UnsafeArrayList {
    public static void main(String[] args) throws InterruptedException {
//        ArrayList<String> list = new ArrayList<>();
//
//        for (int i = 0; i < 10000; i++) {
//            new Thread(()->{
//                list.add(Thread.currentThread().getName());
//            }).start();
//        }
//        //Thread.sleep(10);
//        System.out.println(list.size());

        CopyOnWriteArrayList<String> list = new CopyOnWriteArrayList<>();
        for (int i = 0; i < 1000; i++) {
            new Thread(() -> {
                list.add(Thread.currentThread().getName());
            }).start();
        }
        Thread.sleep(1000);
        System.out.println(list.size());


//        Vector<String> list = new Vector<String>();
//        for (int i = 0; i < 10000; i++) {
//            new Thread(() -> {
//                list.add(Thread.currentThread().getName());
//            }).start();
//        }
//        //Thread.sleep(1000);
//        System.out.println(list.size());


//        LinkedList<String> list = new LinkedList<String>();
//        for (int i = 0; i < 10000; i++) {
//            new Thread(() -> {
//                list.add(Thread.currentThread().getName());
//            }).start();
//        }
//        //Thread.sleep(1000);
//        System.out.println(list.size());
    }
}

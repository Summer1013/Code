package com.yuwei.lesson04;

import java.util.ArrayList;
import java.util.Vector;
import java.util.concurrent.CopyOnWriteArrayList;

public class SafeArrayList {
    public static void main(String[] args) throws InterruptedException {
        ArrayList<String> list = new ArrayList<String>();

        for (int i = 0; i < 10000; i++) {
            new Thread(() -> {
                synchronized (list) {
                    list.add(Thread.currentThread().getName());
                }
            }).start();
        }
        Thread.sleep(3000);//不增加睡眠还是不安全
        System.out.println(list.size());
    }
}

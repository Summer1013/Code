package com.yuwei.lesson04;

public class SafeBank {
    public static void main(String[] args) {
        Account1 account = new Account1(100,"结婚基金");
        Drawing1 you = new Drawing1(account, 50, "你");
        Drawing1 he = new Drawing1(account, 100, "何");
        you.start();
        he.start();

    }
}
class Account1{
    int money;
    String name;

    public Account1(int money,String name){
        this.money = money;
        this.name = name;
    }
}
class Drawing1 extends Thread{
    Account1 account1;
    int drawingMoney;
    int nowMoney;

    public Drawing1(Account1 account1, int drawingMoney, String name){
        super(name);
        this.account1 = account1;
        this.drawingMoney = drawingMoney;
    }

    //取钱
    @Override
    public  void run() {
        synchronized (account1) {
            //判断有没有钱
            if (account1.money - drawingMoney < 0) {
                System.out.println(Thread.currentThread().getName() + "钱不够了,取不了");
                return;
            }
            //sleep可以放大问题的发生性
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            //卡内余额 = 余额 - 你取的钱
            account1.money = account1.money - drawingMoney;
            //你手里的钱
            nowMoney = nowMoney + drawingMoney;

            System.out.println(account1.name + "余额为:" + account1.money);
            System.out.println(this.getName() + "手里的钱" + nowMoney);
        }
    }
}


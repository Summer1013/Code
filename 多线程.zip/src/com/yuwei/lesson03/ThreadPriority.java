package com.yuwei.lesson03;

public class ThreadPriority {
    public static void main(String[] args) {
        System.out.println(Thread.currentThread().getName() + "-->" + Thread.currentThread().getPriority());

        S s = new S();

        Thread a = new Thread(s);
        Thread b = new Thread(s);
        Thread c = new Thread(s);
        Thread d = new Thread(s);
        Thread e = new Thread(s);
        Thread f = new Thread(s);

        a.setPriority(1);
        a.start();

        b.setPriority(4);
        b.start();

        c.setPriority(Thread.MAX_PRIORITY);
        c.start();

        d.setPriority(2);
        d.start();

        e.setPriority(3);
        e.start();

        f.setPriority(8);
        f.start();
    }
}
class S implements Runnable{

    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName() + "-->" + Thread.currentThread().getPriority());
    }
}

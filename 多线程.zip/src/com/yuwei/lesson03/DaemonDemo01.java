package com.yuwei.lesson03;

public class DaemonDemo01 {
    public static void main(String[] args) {
        God god = new God();
        You you = new You();
        Thread thread = new Thread(god);
        thread.setDaemon(true);//默认是false表示是用户线程
        thread.start();

        new Thread(you).start();
    }
}
class You implements Runnable{
    @Override
    public void run() {
        for (int i = 0; i < 36525; i++) {
            System.out.println("开心的生活!");
        }
        System.out.println("再见了这个世界!");
    }
}
class God implements Runnable{
    @Override
    public void run() {
        while (true) {
            System.out.println("我一直在!");
        }
    }
}


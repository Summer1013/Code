package com.yuwei.lesson01;

public class ThreadStateYield {

    public static void main(String[] args) throws InterruptedException {
        c c = new c();
        new Thread(c,"a").start();
        new Thread(c,"b").start();
    }



}
class c implements Runnable{

    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName() + "线程开始");
        Thread.yield();
        System.out.println(Thread.currentThread().getName() + "线程结束");
    }
}

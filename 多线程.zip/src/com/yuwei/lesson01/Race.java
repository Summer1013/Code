package com.yuwei.lesson01;

public class Race implements Runnable{

    private boolean winnerFlag = false;

    @Override
    public void run() {
        for (int i = 1; i <= 100; i++) {
            System.out.println(Thread.currentThread().getName() + "--->跑了" + i + "步");

            if(Thread.currentThread().getName().equals("兔子") && i == 50){
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            if(gameOver(i)){
                winnerFlag = true;
                break;
            }
        }
    }

    public boolean gameOver(int steps){

        if(winnerFlag){
            return true;
        }
        if (steps == 100){
            System.out.println("winner = " + Thread.currentThread().getName());
            return true;
        }
        return false;
    }

    public static void main(String[] args) {
        Race race = new Race();

        new Thread(race,"兔子").start();
        new Thread(race,"乌龟").start();
    }
}

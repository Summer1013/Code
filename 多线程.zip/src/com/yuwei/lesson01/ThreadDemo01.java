package com.yuwei.lesson01;

public class ThreadDemo01 extends Thread{
    public static void main(String[] args) {
        new ThreadDemo01().start();
        //main线程,主线程
        for (int i = 0; i < 2000; i++) {
            System.out.println("main线程" + i);
        }

    }

    @Override
    public void run() {
        //run方法线程体
        for (int i = 0; i < 2000; i++) {
            System.out.println("run方法线程" + i);
        }
    }
}

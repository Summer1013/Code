package com.yuwei.lesson01;

public class RunnableDemo02 implements Runnable{
    private static int ticketNum = 1000;


    @Override
    public void run() {
        for (int i = 1; i <= 1000; i++) {
            System.out.println(Thread.currentThread().getName() + "--->买到了第" + ticketNum-- + "张票");
        }
    }

    public static void main(String[] args) {
        RunnableDemo02 runnableDemo02 = new RunnableDemo02();

        new Thread(runnableDemo02,"小于").start();
        new Thread(runnableDemo02,"小何").start();
        new Thread(runnableDemo02,"小鱼").start();

        //三个人同时抢一个资源 会导致资源为负数 或者抢到同一个资源  所以我们要学习并发
    }
}

package com.yuwei.lesson01;

public class ThreadStateStop implements Runnable{
    private boolean flag = true;
    public static void main(String[] args) {
        ThreadStateStop threadStateStop = new ThreadStateStop();
        new Thread(threadStateStop).start();

        for (int i = 0; i < 1000; i++) {
            if(i == 900){
                threadStateStop.stop();
                System.out.println("run线程结束");
            }
            System.out.println("main线程" + i);
        }
    }

    @Override
    public void run() {
        int i = 0;
        while (flag){
            System.out.println("run线程" + i++);
        }
    }

    public void stop(){
        this.flag = false;
    }

}

package com.yuwei.lesson01;

import javax.xml.crypto.Data;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.SimpleFormatter;

import static java.lang.System.currentTimeMillis;

public class ThreadStateSleep{

    public static void main(String[] args) throws InterruptedException {
        //s();
        Date date = new Date(System.currentTimeMillis());
        while (true){
            Thread.sleep(1000);
            System.out.println(new SimpleDateFormat("HH:mm:ss").format(date));
            date = new Date(System.currentTimeMillis());
        }
    }


    public static void s() throws InterruptedException {
        int i = 100;
        while (true){
            Thread.sleep(1000);
            System.out.println(i--);
            if (i<0){
                break;
            }
        }
    }

}

package com.yuwei.lesson01;

public class ThreadStateJoin implements Runnable{

    public static void main(String[] args) throws InterruptedException {
        ThreadStateJoin threadStateJoin = new ThreadStateJoin();
        Thread vip = new Thread(threadStateJoin, "vip线程");
        vip.start();

        for (int i = 0; i < 200; i++) {
            if(i == 151){
                vip.join();
            }
            System.out.println("main" + "->" + i);
        }
    }

    @Override
    public void run() {
        for (int i = 0; i < 1000; i++) {
            System.out.println(Thread.currentThread().getName() + "->" + i);
        }
    }
}



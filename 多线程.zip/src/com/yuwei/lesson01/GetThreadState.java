package com.yuwei.lesson01;

public class GetThreadState{
    public static void main(String[] args) throws InterruptedException {
        Thread thread = new Thread(()->{
            try {
                System.out.println("222222222");
                System.out.println("222222222");
                System.out.println("222222222");
                System.out.println("222222222");
                System.out.println("222222222");
                System.out.println("222222222");
                Thread.sleep(10000);
                System.out.println("11111111111111111111111111");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        System.out.println(thread.getState());
        thread.start();
        System.out.println(thread.getState());
        while (thread.getState() != Thread.State.TERMINATED){
            Thread.sleep(100);
            System.out.println(thread.getState());
        }
    }


}

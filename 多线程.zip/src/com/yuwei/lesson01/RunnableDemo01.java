package com.yuwei.lesson01;

public class RunnableDemo01 implements Runnable{

    public static void main(String[] args) {

        RunnableDemo01 runnableDemo01 = new RunnableDemo01();
        new Thread(runnableDemo01).start();
        for (int i = 0; i < 1000; i++) {
            System.out.println("2222222222222222222222");
        }
    }

    @Override
    public void run() {
        for (int i = 0; i < 1000; i++) {
            System.out.println("1111111111111111111111111111");
        }
    }
}

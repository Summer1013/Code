package com.yuwei.lesson01;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.net.URL;

public class ThreadWebDownload extends Thread{


    private String url;
    private String fileName;

    public ThreadWebDownload(String url, String fileName){
        this.url = url;
        this.fileName  = fileName;
    }

    @Override
    public void run() {
        WebDownloader webDownloader = new WebDownloader();
        try {
            webDownloader.WebDownload(url,fileName);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("下载失败!!!");
            System.exit(0);
        }
        System.out.println(fileName + "文件下载成功");

    }
    public static void main(String[] args) {
        ThreadWebDownload threadWebDownload1 = new ThreadWebDownload("https://www.kuangstudy.com/assert/course/c1/06.jpg","1.png");
        ThreadWebDownload threadWebDownload2 = new ThreadWebDownload("https://www.kuangstudy.com/assert/course/c1/07.jpg","2.png");
        ThreadWebDownload threadWebDownload3 = new ThreadWebDownload("https://www.kuangstudy.com/assert/course/c1/08.jpg","3.png");

        threadWebDownload1.start();
        threadWebDownload2.start();
        threadWebDownload3.start();

    }
}
class WebDownloader{
    public void WebDownload(String url, String fileName) throws IOException {
        try {
//            URL url1 = new URL(url);
//            HttpURLConnection urlConnection = (HttpURLConnection) url1.openConnection();
//            InputStream inputStream = urlConnection.getInputStream();
//            FileOutputStream fileOutputStream = new FileOutputStream(fileName);
//            byte[] bytes = new byte[1024 * 1024];
//            int len;
//            while ((len = inputStream.read(bytes)) != -1){
//                fileOutputStream.write(bytes,0,len);
//            }
            FileUtils.copyURLToFile(new URL(url),new File(fileName));

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}


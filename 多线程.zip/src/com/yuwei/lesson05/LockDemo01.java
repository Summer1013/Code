package com.yuwei.lesson05;

import java.util.concurrent.locks.ReentrantLock;

public class LockDemo01 {
    public static void main(String[] args) {
        BuyTicket buyTicket = new BuyTicket();

        new Thread(buyTicket).start();
        new Thread(buyTicket).start();
        new Thread(buyTicket).start();
    }
}
class BuyTicket implements Runnable{
    private int ticketNums = 10;
    private final ReentrantLock lock = new ReentrantLock();

    @Override
    public void run() {
        while (true){
            try {
                lock.lock();//加锁
                if(ticketNums > 0){
                    System.out.println(ticketNums--);
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }else {
                    break;
                }
            }finally {
                lock.unlock();//收锁
            }

        }
    }
}

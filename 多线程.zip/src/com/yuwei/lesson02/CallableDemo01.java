package com.yuwei.lesson02;

import org.apache.commons.io.FileUtils;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.concurrent.*;

public class CallableDemo01 implements Callable<Boolean> {
    String url;
    String fileName;

    public static void main(String[] args) throws ExecutionException, InterruptedException {
        CallableDemo01 callableDemo01 = new CallableDemo01("https://www.kuangstudy.com/assert/course/c1/06.jpg", "4.png");
        CallableDemo01 callableDemo02 = new CallableDemo01("https://www.kuangstudy.com/assert/course/c1/06.jpg", "5.png");
        CallableDemo01 callableDemo03 = new CallableDemo01("https://www.kuangstudy.com/assert/course/c1/06.jpg", "6.png");

        //创建执行服务
        ExecutorService service = Executors.newFixedThreadPool(3);

        //提交执行
        Future<Boolean> submit1 = service.submit(callableDemo01);
        Future<Boolean> submit2 = service.submit(callableDemo02);
        Future<Boolean> submit3 = service.submit(callableDemo03);

        //获取结果
        Boolean result1 = submit1.get();
        Boolean result2 = submit2.get();
        Boolean result3 = submit3.get();

        //关闭服务
        service.shutdownNow();

    }

    public CallableDemo01(String url, String fileName){
        this.url = url;
        this.fileName = fileName;
    }

    @Override
    public Boolean call() throws Exception {
        downloader downloader = new downloader();
        downloader.download(url,fileName);
        System.out.println("文件名为:" + fileName + " 下载完成!");

        return true;
    }
}
class downloader{
    public void download(String url, String fileName){
        try {
            FileUtils.copyURLToFile(new URL(url),new File(fileName));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

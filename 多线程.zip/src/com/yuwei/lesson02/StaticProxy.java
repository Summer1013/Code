package com.yuwei.lesson02;

import java.util.HashMap;

//静态代理模式:
//真实对象和代理对象都要实现同一个接口
//代理对象要代理真实角色

//好处:
//代理对象可以做很多真实对象做不了的事情
//真实对象专注做自己的事情
public class StaticProxy {
    public static void main(String[] args) {
        new WeddingCompany(new People()).HappyMarry();
        new WeddingCompany(new s()).HappyMarry();
    }

}
interface Marry{
    //人间四大喜事
        //久旱逢甘霖
        //他乡遇故知
        //洞房花烛夜
        //金榜题名时

    void HappyMarry();
}
class People implements Marry{
    @Override
    public void HappyMarry() {
        System.out.println("何元春与于伟今天结婚啦");
    }
}

class s implements Marry{

    @Override
    public void HappyMarry() {
        System.out.println("sdada");
    }
}

class WeddingCompany implements Marry{
    private Marry marry;

    public WeddingCompany(Marry marry){
        this.marry = marry;
    }

    @Override
    public void HappyMarry() {
        this.marry.HappyMarry();
    }
}

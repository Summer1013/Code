package com.yuwei.lesson02;

public class LambdaExpression {

    //3.静态内部类
    static class class2 implements i{
        @Override
        public void classPort() {
            System.out.println("静态内部类");
        }
    }

    public static void main(String[] args) {
        i i = new class1();
        i.classPort();

        i = new class2();
        i.classPort();
        //4.局部内部类
        class class3 implements i{
            @Override
            public void classPort() {
                System.out.println("局部内部类");
            }
        }
        i = new class3();
        i.classPort();
        //5.匿名内部类,没有类的名称,必须借助接口或者父类
        i = new i() {
            @Override
            public void classPort() {
                System.out.println("匿名内部类");
            }
        };
        i.classPort();
        //6.用lambda简化,用于接口只有一个方法的情况
        i = ()-> {System.out.println("lambda简化输出");};
        i.classPort();
        i = ()-> System.out.println("去掉大括号 lambda简化输出");
        i.classPort();
    }

}
//1.定义一个函数接口:接口只有一个方法
interface i{
    void classPort();
}
//2.外部类
class class1 implements i{

    @Override
    public void classPort() {
        System.out.println("外部类");
    }
}

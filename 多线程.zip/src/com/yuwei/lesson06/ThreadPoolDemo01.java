package com.yuwei.lesson06;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThreadPoolDemo01 {
    public static void main(String[] args) {
        //1.创建线程池服务
        ExecutorService service = Executors.newFixedThreadPool(10);
        //2.服务执行
        for (int i = 0; i < 100; i++) {
            service.execute(new MyThread());
        }
        //3.关闭服务
        service.shutdown();
    }
}
class MyThread implements Runnable{
    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName());
    }
}

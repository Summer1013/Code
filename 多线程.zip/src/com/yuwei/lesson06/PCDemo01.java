package com.yuwei.lesson06;

//测试:生产者消费者问题--->利用缓冲区解决:管程法

//生产者  消费者  产品  缓冲区
public class PCDemo01 {
    public static void main(String[] args) {
        SynContainer synContainer = new SynContainer();

        new Producer(synContainer).start();
        new Consumer(synContainer).start();
    }
}
//生产者
class Producer extends Thread{
    SynContainer synContainer = new SynContainer();

    public Producer(SynContainer synContainer){
        this.synContainer = synContainer;
    }

    @Override
    public void run() {
        for (int i = 1; i <= 1000; i++) {
            synContainer.push(new Chicken(i));
            System.out.println("生产了id为 " + i + " 的鸡");
        }
    }
}

//消费者
class Consumer extends Thread{
    SynContainer synContainer = new SynContainer();

    public Consumer(SynContainer synContainer){
        this.synContainer = synContainer;
    }

    @Override
    public void run() {
        for (int i = 0; i < 1000; i++) {
            System.out.println("消费了id为 " + synContainer.pop().id + " 的鸡");
        }
    }
}

//产品
class Chicken{
    int id;//产品id

    public Chicken(int id) {
        this.id = id;
    }
}

//缓冲区
class SynContainer{
    //容器大小
    Chicken[] chickens = new Chicken[10];
    //计数器
    int count = 0;

    //生产者放入产品
    public synchronized void push(Chicken chicken){
        //如果容器放满了
        if(count == chickens.length){
            //等待消费者来消费
            try {
                this.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        //生产者将产品放入容器
        chickens[count++] = chicken;
        //容器中有鸡了,通知消费者来取
        this.notifyAll();

    }

    //消费者取产品
    public synchronized Chicken pop(){
        //如果容器为0
        if(count == 0){
            //等待生产者生产
            try {
                this.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        //如果容易不为0,则取产品
        count--;
        Chicken chicken = chickens[count];

        //吃完了这只,容器就不是满的,通知生产者再生产
        this.notifyAll();

        return chicken;
    }
}



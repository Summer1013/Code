package com.yuwei.lesson06;

//信号灯法
public class PCDemo02 {
    public static void main(String[] args) {
        TV tv = new TV();
        new Player(tv).start();
        new Watcher(tv).start();
    }
}

//演员
class Player extends Thread{
    TV tv = new TV();

    public Player(TV tv) {
        this.tv = tv;
    }

    @Override
    public void run() {
        for (int i = 0; i < 20; i++) {
            if (i%2 == 0){
                this.tv.play("长津湖");
            }else {
                this.tv.play("水门桥");
            }
        }
    }
}
//观众
class Watcher extends Thread{
    TV tv = new TV();

    public Watcher(TV tv) {
        this.tv = tv;
    }

    @Override
    public void run() {
        for (int i = 0; i < 20; i++) {
            this.tv.watch();
        }
    }
}
//TV
class TV{
    //演员表演,观众等待T
    //观众观看,演员等待F
    boolean flag = true;
    //表演的节目
    String voice;

    //表演
    public synchronized void play(String voice){
        if(!flag){
            try {
                this.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("演员表演了--->" + voice);
        //通知观众来看
        this.flag = !this.flag;
        this.notifyAll();
        this.voice = voice;
    }
    //观看
    public synchronized void watch(){
        if(flag){
            try {
                this.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("观众观看了->>>" + voice);
        //通知演员表演
        this.flag = !this.flag;
        this.notifyAll();
    }
}

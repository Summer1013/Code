package Demo;

/**
 * @author 夏天
 * 有bug请联系QQ:1205232048
 * 做什么:
 */
public class Demo05 {
    public static void main(String[] args) {
        String s = "abc";
        String abc = new String("abc");
        System.out.println(s == abc);
        System.out.println(s.hashCode());
        System.out.println(abc.hashCode());
    }
}

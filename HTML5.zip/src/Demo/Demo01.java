package Demo;

/**
 * @author 夏天
 * 有bug请联系QQ:1205232048
 * 做什么:
 */
public class Demo01 {
    public static void main(String[] args) {
        int i = 1;
        if(1==1 && (++i)==2){
        }
        System.out.println(i);
        if(1==0 && (++i)==2){
        }
        System.out.println(i);
        if(1==0 & (++i)==2){
        }
        System.out.println(i);
    }
}

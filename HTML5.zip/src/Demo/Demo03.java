package Demo;

/**
 * @author 夏天
 * 有bug请联系QQ:1205232048
 * 做什么:
 */
public class Demo03 {
    public static void main(String[] args) {
        final String a = "a";
        System.out.println(a.concat("改变了"));

    }
}

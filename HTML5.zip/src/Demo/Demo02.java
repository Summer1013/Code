package Demo;

/**
 * @author 夏天
 * 有bug请联系QQ:1205232048
 * 做什么:
 */
public class Demo02 {
    public static void main(String[] args) {
        System.out.println(Math.round(11.5));
        System.out.println(Math.round(11.4));
        System.out.println(Math.round(-11.5));
        System.out.println(Math.round(2.2));
        System.out.println(Math.round(2.8));
    }
}

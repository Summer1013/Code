package Demo;

/**
 * @author 夏天
 * 有bug请联系QQ:1205232048
 * 做什么:
 */
public class Demo06 {
    public static void main(String[] args) {
        String s = new String("asdgasgasg");
        //indexof();返回指定字符的的索引。
        System.out.println(s.indexOf("s"));
        //charAt();返回指定索引处的字符。
        System.out.println(s.charAt(1));
        //replace();字符串替换。
        System.out.println(s.replace("asd", "ad"));
        //trim();去除字符串两端空格。
        //
        //splt()；字符串分割，返回分割后的字符串数组。
        //
        //getBytes()；返回字符串byte类型数组。
        //
        //length()；返回字符串长度。
        //
        //toLowerCase();将字符串转换为小写字母。 •toUpperCase();将字符串转换为大写字母。
        //
        //substring();字符串截取。
        //
        //equals();比较字符串是否相等。
    }
}

package com.yuwei.lesson01;

/**
 * @author 于伟
 * 做什么:讲解OOM调优
 */
public class test01 {
    public static void main(String[] args) {
        //返回虚拟机试图使用的最大内存
        long maxMemory = Runtime.getRuntime().maxMemory();

        //返回虚拟机的初始化总内存
        long totalMemory = Runtime.getRuntime().totalMemory();

        //1796MB 大约为运行内存的1/4
        System.out.println("maxMemory = " + maxMemory + "字节" + (maxMemory/(double)1024/1024)+ "MB");
        //123MB  大约为运行内存的1/64
        System.out.println("totalMemory = " + totalMemory + "字节" + (totalMemory/(double)1024/1024)+ "MB");

        //OOM
        //1.尝试扩大堆内存结果
        //2.分析内存,看一下是哪个地方的问题(专业工具)
    }
}

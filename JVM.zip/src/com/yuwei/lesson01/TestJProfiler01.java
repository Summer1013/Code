package com.yuwei.lesson01;

/**
 * @author 于伟
 * 做什么:
 */
//-Xms1m -Xmx1m -XX:+HeapDumpOnOutOfMemoryError
public class TestJProfiler01 extends Thread{
    public static void main(String[] args) {
        String summer = "summer";
        try {
            while (true) {
                summer += "sssssssssssssssssssssssssssssss";
            }
        }catch (Error e){
            e.printStackTrace();
        }


    }
}

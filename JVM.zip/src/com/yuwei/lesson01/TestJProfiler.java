package com.yuwei.lesson01;

import java.util.ArrayList;

/**
 * @author 于伟
 * 做什么:测试JProfiler工具
 */
public class TestJProfiler {
    byte[] bytes = new byte[1024 * 1024];

    public static void main(String[] args) {
        ArrayList<TestJProfiler> list = new ArrayList<>();
        int num = 0;

        try{
            while (true){
                list.add(new TestJProfiler());
                num += 1;
            }
        }catch (Error e){
            System.out.println(num);
            e.printStackTrace();
        }

    }
}



public class Plus { 

	//��дһ��main����
	public static void main(String[] args) {
		System.out.println(100 + 98); //198
		System.out.println("100" + 98);//10098

		System.out.println(100 + 3 + "hello");//103hello
		System.out.println("hello" + 100 +3); //hello1003

	}
}
public class Homework01 { 

	//��дһ��main����
	public static void main(String[] args) {
		
		int n1;
        n1 = 13;
        int n2;
        n2 = 17;
        int n3;
        n3 = n1 + n2;
        System.out.println("n3 = " + n3);//30
        int n4 = 38;
        int n5 = n4 - n3;
        System.out.println("n5 = " + n5);//8

	}
}


public class Homework02 { 

	//±àÐ´Ò»¸ömain·½·¨
	public static void main(String[] args) {
		//Ê¹ÓÃcharÀàÐÍ£¬·Ö±ð±£´æ \n \t \r  \\  1  2  3µÈ×Ö·û£¬²¢´òÓ¡Êä³ö
		char c1 = '\n'; //»»ÐÐ
		char c2 = '\t'; //ÖÆ±íÎ» ctrl + d
		char c3 = '\r'; //»Ø³µ
		char c4 = '\\'; //Êä³ö\
		char c5 = '1'; //»»ÐÐ
		char c6 = '2'; //»»ÐÐ
		char c7 = '3'; //»»ÐÐ
		System.out.println(c1);
		System.out.println(c2);
		System.out.println(c3);
		System.out.println(c4);
		System.out.println(c5);
		System.out.println(c6);
		System.out.println(c7);
	}
}
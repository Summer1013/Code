package com.yuwei.Annotation;

//什么是注解
public class AnnotationDemo01 {
    //@Override  重写的注解
    @Override
    public String toString() {
        return super.toString();
    }
    //@Deprecated  过时的注解,不推荐程序员使用,或者存在更好的方法,但是可以使用
    @Deprecated
    public static void test(){

    }
    //@SuppressWarnings  抑制警告的注解
    @SuppressWarnings("all")
    public void test2(){
        int abc;
    }
}

package com.yuwei.Annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

//自定义注解
public class AnnotationDemo03 {
    //注解可以显示赋值 如果没有默认值 我们就应该给注解赋值
    @MyAnnotation2(age = 18,name = "夏天")
    public void test(){

    }

    @MyAnnotation3("summer")
    public void test1(){

    }
}

@Target({ElementType.TYPE,ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@interface MyAnnotation2{
    //注解的参数 : 参数类型 + 参数名 + ();
    String name() default "";
    int age() default 0;
    int id() default -1;
    String[] schools() default {"华科","防灾"};
}

@Target({ElementType.TYPE,ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@interface MyAnnotation3{
    String value();//如果只有一个参数则写成value 在注解中就不用写参数名 =
}

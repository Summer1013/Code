package com.yuwei.Reflection;

import java.lang.annotation.*;
import java.lang.reflect.Field;

public class ReflectionDemo10 {
    public static void main(String[] args) throws ClassNotFoundException, NoSuchFieldException {
        Class<?> c1 = Class.forName("com.yuwei.Reflection.Student1");

        //通过反射获得注解
        Annotation[] declaredAnnotations = c1.getDeclaredAnnotations();
        for (Annotation declaredAnnotation : declaredAnnotations) {
            System.out.println(declaredAnnotation);
        }

        //获得注解的value的值
        TableWei tableWei = c1.getDeclaredAnnotation(TableWei.class);
        String value = tableWei.value();
        System.out.println(value);

        //获得类指定的注解
        //1 先得到某个属性
        //2 再通过属性去得到属性的注解
        //3 再去得到注解的信息
        Field id = c1.getDeclaredField("id");
        FiledWei filedWei = id.getDeclaredAnnotation(FiledWei.class);
        System.out.println(filedWei.columnName());
        System.out.println(filedWei.type());
        System.out.println(filedWei.length());

    }
}
@TableWei("db_1")
class Student1{
    @FiledWei(columnName = "id",type = "int",length = 10)
    private int id;
    @FiledWei(columnName = "age",type = "int",length = 10)
    private int age;
    @FiledWei(columnName = "name",type = "varchar",length = 3)
    private String name;

    public Student1() {

    }

    public Student1(int id, int age, String name) {
        this.id = id;
        this.age = age;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


}

//类名的注解
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@interface TableWei{
    String value();
}

//属性的注解
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@interface FiledWei{
    String columnName();
    String type();
    int length();
}

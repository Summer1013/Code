package com.yuwei.Reflection;

public class ReflectionDemo07 {
    public static void main(String[] args) throws ClassNotFoundException, NoSuchFieldException, NoSuchMethodException {
        Class<?> c1 = Class.forName("com.yuwei.Reflection.cat");

        c1.getName();//获得全类名
        c1.getSimpleName();//获得类名

        c1.getFields();//只能找到public修饰的字段
        c1.getDeclaredFields();//找到所有字段
        c1.getField("a");//找到指定字段,且是public修饰
        c1.getDeclaredField("name");//找到指定字段

        c1.getMethods();//获得本类及父类的所有public方法
        c1.getDeclaredFields();//获得本类所有方法
        c1.getMethod("getColor");//得到指定的public方法
        c1.getDeclaredMethod("test");//得到指定的方法

        c1.getConstructors();//得到本类中所有public构造器
        c1.getDeclaredConstructors();//得到本类中所有构造器
        c1.getConstructor();//得到指定的public构造器
        System.out.println(c1.getDeclaredConstructor(int.class));//得到指定的构造器

    }
}

package com.yuwei.Reflection;

public class ReflectionDemo06 {
    public static void main(String[] args) throws ClassNotFoundException {
        //获得系统类加载器
        ClassLoader systemClassLoader = ClassLoader.getSystemClassLoader();
        System.out.println(systemClassLoader);//sun.misc.Launcher$AppClassLoader@18b4aac2

        //获得系统类加载器的父类加载器 ---> 扩展类加载器
        ClassLoader parent = systemClassLoader.getParent();
        System.out.println(parent);//sun.misc.Launcher$ExtClassLoader@1540e19d

        //获得扩展类加载器的父类加载器 ---> 根加载器(c/c++)
        ClassLoader parent1 = parent.getParent();
        System.out.println(parent1);//null

        //测试当前类是哪个加载器加载的
        ClassLoader classLoader = Class.forName("com.yuwei.Reflection.ReflectionDemo06").getClassLoader();
        System.out.println(classLoader);//sun.misc.Launcher$AppClassLoader@18b4aac2

        //测试JDK内置类是哪个加载器加载的
        ClassLoader classLoader1 = Class.forName("java.io.OutputStream").getClassLoader();
        System.out.println(classLoader1);//null

        //如何获得系统类加载器可以加载的路径
        System.out.println(System.getProperty("java.class.path"));
        /**
         * E:\JDK\jdk8\jre\lib\charsets.jar;
         * E:\JDK\jdk8\jre\lib\deploy.jar;
         * E:\JDK\jdk8\jre\lib\ext\access-bridge-64.jar;
         * E:\JDK\jdk8\jre\lib\ext\cldrdata.jar;
         * E:\JDK\jdk8\jre\lib\ext\dnsns.jar;
         * E:\JDK\jdk8\jre\lib\ext\jaccess.jar;
         * E:\JDK\jdk8\jre\lib\ext\jfxrt.jar;
         * E:\JDK\jdk8\jre\lib\ext\localedata.jar;
         * E:\JDK\jdk8\jre\lib\ext\nashorn.jar;
         * E:\JDK\jdk8\jre\lib\ext\sunec.jar;
         * E:\JDK\jdk8\jre\lib\ext\sunjce_provider.jar;
         * E:\JDK\jdk8\jre\lib\ext\sunmscapi.jar;
         * E:\JDK\jdk8\jre\lib\ext\sunpkcs11.jar;
         * E:\JDK\jdk8\jre\lib\ext\zipfs.jar;
         * E:\JDK\jdk8\jre\lib\javaws.jar;
         * E:\JDK\jdk8\jre\lib\jce.jar;
         * E:\JDK\jdk8\jre\lib\jfr.jar;
         * E:\JDK\jdk8\jre\lib\jfxswt.jar;
         * E:\JDK\jdk8\jre\lib\jsse.jar;
         * E:\JDK\jdk8\jre\lib\management-agent.jar;
         * E:\JDK\jdk8\jre\lib\plugin.jar;
         * E:\JDK\jdk8\jre\lib\resources.jar;
         * E:\JDK\jdk8\jre\lib\rt.jar;
         * D:\编程\Java\Code\注解和反射\out\production\注解和反射;
         * E:\IntelliJ IDEA 2020.2\lib\idea_rt.jar
         */
    }
}

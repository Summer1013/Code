package com.yuwei.Reflection;

public class ReflectionDemo01 {
    public static void main(String[] args) throws ClassNotFoundException {
        //通过反射来获取该类的Class对象
        Class c1 = Class.forName("com.yuwei.Reflection.cat");
        System.out.println(c1);

        //一个类在内存中只有一个Class对象
        //一个类被加载后,类的整个结构都会被封装在Class对象中
        Class c2 = Class.forName("com.yuwei.Reflection.cat");
        Class c3 = Class.forName("com.yuwei.Reflection.cat");
        Class c4 = Class.forName("com.yuwei.Reflection.cat");
        System.out.println(c2.hashCode());
        System.out.println(c3.hashCode());
        System.out.println(c4.hashCode());

    }
}
class cat{
    private String name;
    private int age;
    private String color;
    public int a;

    public cat() {

    }
    private cat(int a){
        this.a = a;
    }

    public cat(String name, int age, String color,int a) {
        this.name = name;
        this.age = age;
        this.color = color;
        this.a = a;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    private void test(){}

    @Override
    public String toString() {
        return "cat{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", color='" + color + '\'' +
                '}';
    }
}

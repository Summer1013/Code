package com.yuwei.Reflection;


import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;

public class ReflectionDemo09 {
    public static void main(String[] args) throws NoSuchMethodException {
        int i = 1;
        Method method = ReflectionDemo09.class.getMethod("test01", Map.class, List.class);

        //generic泛型
        //parameter参数
        //parameterized结构化参数
        Type[] genericParameterTypes = method.getGenericParameterTypes();
        for (Type genericParameterType : genericParameterTypes) {
            System.out.println(i++ + " " + genericParameterType);
            if(genericParameterType instanceof ParameterizedType){
                Type[] actualTypeArguments = ((ParameterizedType) genericParameterType).getActualTypeArguments();
                for (Type actualTypeArgument : actualTypeArguments) {
                    System.out.println(i++ + " " + actualTypeArgument);
                }
            }
        }

        method = ReflectionDemo09.class.getMethod("test02", null);
        Type genericReturnType = method.getGenericReturnType();
        if(genericReturnType instanceof ParameterizedType){
            Type[] actualTypeArguments = ((ParameterizedType) genericReturnType).getActualTypeArguments();
            for (Type actualTypeArgument : actualTypeArguments) {
                System.out.println(i++ + " " + actualTypeArgument);
            }
        }


    }

    public void test01(Map<String,cat> map, List<cat> list){
        System.out.println("test01");
    }

    public Map<String,cat> test02(){
        System.out.println("test02");
        return null;
    }
}

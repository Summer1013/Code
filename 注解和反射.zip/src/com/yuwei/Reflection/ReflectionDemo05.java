package com.yuwei.Reflection;

import java.awt.*;

public class ReflectionDemo05 {
    static {
        System.out.println("main类被加载");
    }
    public static void main(String[] args) throws ClassNotFoundException {
        //主动引用
        Son son = new Son();
        System.out.println();

        //反射也会主动引用
        Class.forName("com.yuwei.Reflection.Son");
        System.out.println();

        //不会产生类的引用的方法
        System.out.println(Son.b);

        Son[] array = new Son[5];
        System.out.println(Son.M);
    }
}
class Father{
    static int b = 2;

    static {
        System.out.println("Father类被加载");
    }
}
class Son extends Father{
    static {
        System.out.println("Son类被加载");
        m = 300;
    }

    static int m = 100;
    static final int M = 1;
}

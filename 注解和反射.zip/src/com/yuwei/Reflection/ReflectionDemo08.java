package com.yuwei.Reflection;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class ReflectionDemo08 {
    public static void main(String[] args) throws Exception{
        //得到class对象
        Class c1 = Class.forName("com.yuwei.Reflection.cat");

        //构造一个对象
        cat a1 = (cat) c1.newInstance();//本质是调用了无参构造器
        System.out.println(a1);

        //通过构造器创建对象
        Constructor constructor = c1.getDeclaredConstructor(String.class, int.class, String.class,int.class);
        cat a2 = (cat) constructor.newInstance("小鱼", 2, "白色",1);
        System.out.println(a2);

        //通过反射调用普通方法
        //invoke 激活的意思
        //(对象, "方法的值")
        cat a3 = (cat) c1.newInstance();
        Method setName = c1.getDeclaredMethod("setName", String.class);
        setName.invoke(a3,"夏天");
        System.out.println(a3.getName());

        //通过反射操作属性
        //不能直接操作私有属性,我们需要关闭程序的安全检测
        cat a4 = (cat) c1.newInstance();
        Field name = c1.getDeclaredField("name");
        name.setAccessible(true);//关闭程序的安全检测
        name.set(a4,"夏天!");
        System.out.println(a4.getName());


    }
}

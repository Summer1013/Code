package com.yuwei.Reflection;

public class ReflectionDemo04 {
    public static void main(String[] args) {
        A a = new A();
        System.out.println(a.m);

        /*
         * 1.加载到内存中,会产生一个A类对象的Class对象
         * 2.链接, 给静态变量赋默认值 m = 0
         * 3.初始化
         * <clinit>(){
         *       System.out.println("A类静态代码块");
         *       m = 300;
         *       m = 100;
         * }
         */
    }
}

class A{


    static {
        System.out.println("A类静态代码块");
        m = 300;
    }

    static int m = 100;


    public A(){
        System.out.println("A类无参构造器");
    }
}

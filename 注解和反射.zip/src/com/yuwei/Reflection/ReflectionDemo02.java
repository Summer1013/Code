package com.yuwei.Reflection;

import java.util.regex.Pattern;

public class ReflectionDemo02 {
    public static void main(String[] args) throws ClassNotFoundException {
        Student student = new Student();
        System.out.println("这个人是" + student.name);
        //1 通过对象获得
        Class c1 = student.getClass();
        System.out.println(c1.hashCode());
        //2 通过forName得到
        Class c2 = Class.forName("com.yuwei.Reflection.Student");
        System.out.println(c2.hashCode());
        //3 通过类名.class获得
        Class c3 = Student.class;
        System.out.println(c3.hashCode());
        //4 基本内置类型的包装类都有一个Type属性
        Class c4 = Integer.TYPE;
        System.out.println(c4.hashCode());
        //获得父类类型
        Class c5 = c1.getSuperclass();
        System.out.println(c5);

    }
}

class Person{
    private String name;

    public Person() {
    }

    public Person(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                '}';
    }
}

class Student extends Person{
    String name;

    public Student() {
        this.name = "学生";
    }
}

class Teacher extends Person{
    String name;

    public Teacher() {
        this.name = "老师";
    }
}

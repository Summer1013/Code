package com.hspedu.final_;

public class FinalExercise02 {
    public static void main(String[] args) {

    }
}
class Something {  //FinalExercise02.java
    public int addOne(final int x) { //下面的代码是否有误，为什么? 1min
        //++x;  //错误,原因是不能修改 final x的值
        return x + 1; //这里是可以.
    }
}

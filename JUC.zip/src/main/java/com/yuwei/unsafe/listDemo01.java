package com.yuwei.unsafe;

import java.lang.invoke.VolatileCallSite;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author 于伟
 * 做什么:演示List并发不安全  并给出解决方案
 */
public class listDemo01 {
    public static void main(String[] args) {
        //单线程下是安全的
        //List<String> list = Arrays.asList("1", "2", "3");
        //list.forEach(System.out::println);

        //报错  java.util.ConcurrentModificationException  并发修改异常
        //并发下 ArrayList是不安全的
        //List<String> list = new ArrayList<>();
        //for (int i = 1; i <= 10; i++) {
        //    new Thread(()->{
        //        list.add(UUID.randomUUID().toString().substring(0,5));
        //        System.out.println(list);
        //    },String.valueOf(i)).start();
        //}

        //解决方案
        //1.用Vector()解决 但是Vector从1.0就有了  ArrayList是1.2才有的   这种方案太太太太low了
        //List<String> list = new Vector<>();
        //for (int i = 1; i <= 10; i++) {
        //    new Thread(()->{
        //        list.add(UUID.randomUUID().toString().substring(0,5));
        //        System.out.println(list);
        //    },String.valueOf(i)).start();
        //}
        //2.用Collections.synchronizedList(new ArrayList<>()) 去解决
        //List<String> list = Collections.synchronizedList(new ArrayList<>());
        //for (int i = 1; i <= 10; i++) {
        //    new Thread(()->{
        //        list.add(UUID.randomUUID().toString().substring(0,5));
        //        System.out.println(list);
        //    },String.valueOf(i)).start();
        //}
        //3. JUC下的.    用new CopyOnWriteArrayList<>()去解决
        //CopyOnWrite写入时复制 COW 计算机程序设计领域的一种优化策略
        //多个线程调用的时候 list 读取的时候(固定) 写入(覆盖)
        //在写入的时候避免覆盖造成数据问题
        List<String> list = new CopyOnWriteArrayList<>();
        for (int i = 1; i <= 10; i++) {
            new Thread(()->{
                list.add(UUID.randomUUID().toString().substring(0,5));
                System.out.println(list);
            },String.valueOf(i)).start();
        }


    }
}

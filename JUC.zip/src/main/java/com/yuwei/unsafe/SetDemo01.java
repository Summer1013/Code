package com.yuwei.unsafe;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArraySet;

/**
 * @author 于伟
 * 做什么:演示Set并发不安全  并给出解决方案
 */
public class SetDemo01 {
    public static void main(String[] args) {
        //报错  java.util.ConcurrentModificationException  并发修改异常
        //并发下 Set是不安全的
        //Set<String> set = new HashSet<>();
        //for (int i = 1; i <= 30; i++) {
        //    new Thread(()->{
        //        set.add(UUID.randomUUID().toString().substring(0,5));
        //        System.out.println(set);
        //    },String.valueOf(i)).start();
        //}

        //解决方案
        //1.用Collections.synchronizedSet(new HashSet<>())解决
        //Set<String> set = Collections.synchronizedSet(new HashSet<>());
        //for (int i = 1; i <= 30; i++) {
        //    new Thread(()->{
        //        set.add(UUID.randomUUID().toString().substring(0,5));
        //        System.out.println(set);
        //    },String.valueOf(i)).start();
        //}
        //2.用JUC下的new CopyOnWriteArraySet<>()解决
        Set<String> set = new CopyOnWriteArraySet<>();
        for (int i = 1; i <= 30; i++) {
            new Thread(()->{
                set.add(UUID.randomUUID().toString().substring(0,5));
                System.out.println(set);
            },String.valueOf(i)).start();
        }


    }
}

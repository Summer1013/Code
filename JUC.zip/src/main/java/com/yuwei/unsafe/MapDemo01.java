package com.yuwei.unsafe;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author 于伟
 * 做什么:演示Map并发不安全  并给出解决方案
 */
public class MapDemo01 {
    public static void main(String[] args) {
        //map是这样用的吗  不是 工作中不用HashMap
        //initialCapacity 容量   loadFactor 加载因子
        //报错  java.util.ConcurrentModificationException  并发修改异常
        //并发下 Map是不安全的
        //Map<String, String> map = new HashMap<>();
        //for (int i = 1; i <= 30; i++) {
        //    new Thread(()->{
        //        map.put(Thread.currentThread().getName(),UUID.randomUUID().toString().substring(0,5));
        //        System.out.println(map);
        //    },String.valueOf(i)).start();
        //}

        //解决方案
        //1.Collections.synchronizedMap(new HashMap<>())
        //Map<String, String> map = Collections.synchronizedMap(new HashMap<>());
        //for (int i = 1; i <= 30; i++) {
        //    new Thread(()->{
        //        map.put(Thread.currentThread().getName(),UUID.randomUUID().toString().substring(0,5));
        //        System.out.println(map);
        //    },String.valueOf(i)).start();
        //}
        //2.JUC下的   new ConcurrentHashMap<>()  需要好好研究  在JavaJDK文档里面有
        Map<String, String> map = new ConcurrentHashMap<>();
        for (int i = 1; i <= 30; i++) {
            new Thread(()->{
                map.put(Thread.currentThread().getName(),UUID.randomUUID().toString().substring(0,5));
                System.out.println(map);
            },String.valueOf(i)).start();
        }
    }
}

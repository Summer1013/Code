package com.yuwei.function;

import java.util.function.Predicate;

/**
 * @author 于伟
 * 做什么:断定型接口Predicate
 */
public class Demo02 {
    public static void main(String[] args) {
        //普通方法测试
        //Predicate<String> stringPredicate = new Predicate<String>() {
        //    @Override
        //    public boolean test(String s) {
        //        return s.isEmpty();
        //    }
        //};
        //System.out.println(stringPredicate.test(""));
        //System.out.println(stringPredicate.test("ad"));

        //lambda方法测试
        Predicate<String> string =(str)->{return str.isEmpty();};
        System.out.println(string.test(""));
        System.out.println(string.test("ad"));

    }
}

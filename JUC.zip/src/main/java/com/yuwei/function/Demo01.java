package com.yuwei.function;

import java.util.function.Function;

/**
 * @author 于伟
 * 做什么:函数型接口Function
 */
public class Demo01 {
    public static void main(String[] args) {
        //普通方法测试接口
        //Function<String, String> s = new Function<String, String>() {
        //    @Override
        //    public String apply(String o) {
        //        return o;
        //    }
        //};
        //System.out.println(s.apply("sss"));

        //用lambda表达式测试接口
        Function function = (str)->{return str;};
        System.out.println(function.apply("ada"));
    }
}

package com.yuwei.function;

import java.util.function.Consumer;

/**
 * @author 于伟
 * 做什么:Consumer消费型接口
 */
public class Demo03 {
    public static void main(String[] args) {
        //普通方法
        //Consumer<String> stringConsumer = new Consumer<String>() {
        //    @Override
        //    public void accept(String o) {
        //        System.out.println(o);
        //    }
        //};
        //
        //stringConsumer.accept("阿诗丹顿");

        //lambda表达式
        Consumer<String> stringConsumer = (s)->{
            System.out.println(s);
        };

        stringConsumer.accept("阿诗丹顿");
    }
}

package com.yuwei.function;

import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * @author 于伟
 * 做什么:Supplier供给型接口
 */
public class Demo04 {
    public static void main(String[] args) {
        //普通方法
        Supplier<String> stringSupplier = new Supplier<String>() {
            @Override
            public String get() {
                return "阿诗丹顿";
            }
        };

        System.out.println(stringSupplier.get());

        //lambda表达式
        Supplier<String> ss = ()->{
            return "阿诗丹顿";
        };

        System.out.println(ss.get());
    }
}

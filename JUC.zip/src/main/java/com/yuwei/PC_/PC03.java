package com.yuwei.PC_;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @author 于伟
 * 做什么:
 */
public class PC03 {
    public static void main(String[] args) {
        O o = new O();

        new Thread(()->{
            for (int i = 0; i < 20; i++) {
                o.a();
            }
        },"A").start();

        new Thread(()->{
            for (int i = 0; i < 20; i++) {
                o.b();
            }
        },"B").start();

        new Thread(()->{
            for (int i = 0; i < 20; i++) {
                o.c();
            }
        },"C").start();

        new Thread(()->{
            for (int i = 0; i < 20; i++) {
                o.d();
            }
        },"D").start();
    }
}
class O{
    private int number = 1;
    Lock lock = new ReentrantLock();
    Condition condition1 = lock.newCondition();
    Condition condition2 = lock.newCondition();
    Condition condition3 = lock.newCondition();
    Condition condition4 = lock.newCondition();

    public void a(){
        lock.lock();
        try{
            if(number != 1){//标志符不是1就等待
                condition1.await();
            }
            number = 2;//设置标志符为2
            condition2.signal();//通知condition2
            System.out.println(Thread.currentThread().getName() + "-->" + "1");
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }

    public void b(){
        lock.lock();
        try{
            if(number != 2){
                condition2.await();
            }
            number = 3;
            condition3.signal();
            System.out.println(Thread.currentThread().getName() + "-->" + "2");
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }

    public void c(){
        lock.lock();
        try{
            if(number != 3){
                condition3.await();
            }
            number = 4;
            condition4.signal();
            System.out.println(Thread.currentThread().getName() + "-->" + "3");
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }

    public void d(){
        lock.lock();
        try{
            if(number != 4){
                condition4.await();
            }
            number = 1;
            condition1.signal();
            System.out.println(Thread.currentThread().getName() + "-->" + "4");
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }
}
package com.yuwei.PC_;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @author 于伟
 * 做什么:通过lock和condition来解决生产者消费者问题
 */
public class PC02 {
    public static void main(String[] args) {
        H h = new H();

        new Thread(()->{
            for (int i = 0; i < 40; i++) {
                h.increment();
            }
        },"A").start();

        new Thread(()->{
            for (int i = 0; i < 40; i++) {
                h.decrement();
            }
        },"B").start();

        new Thread(()->{
            for (int i = 0; i < 40; i++) {
                h.increment();
            }
        },"C").start();

        new Thread(()->{
            for (int i = 0; i < 40; i++) {
                h.decrement();
            }
        },"D").start();
    }

}
class H{
    private int number = 0;
    Lock lock = new ReentrantLock();
    Condition condition = lock.newCondition();

    public void increment(){
        lock.lock();
        try {
            while (number != 0){
                condition.await();
            }
            number++;
            System.out.println(Thread.currentThread().getName() + "-->" + number);
            condition.signalAll();
        } catch (Exception e){
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }

    public void decrement(){
        lock.lock();
        try {
            while (number == 0){
                condition.await();
            }
            number--;
            System.out.println(Thread.currentThread().getName() + "-->" + number);
            condition.signalAll();
        } catch (Exception e){
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }
}

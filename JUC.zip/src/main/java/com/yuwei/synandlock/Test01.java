package com.yuwei.synandlock;

/**
 * @author 于伟
 * 做什么:查看cup的核数
 */
public class Test01 {
    public static void main(String[] args) {
        int i = Runtime.getRuntime().availableProcessors();
        System.out.println(i);
    }
}

package com.yuwei.synandlock;

/**
 * @author 于伟
 * 做什么:基本的卖票例子
 * 真正的线程开发 线程就是一个单独的资源类 没有任何附属操作
 * 属性 方法
 */
public class SaleTicketSynchronized {
    public static void main(String[] args) {
        //并发 多线程操作用一个资源
        Ticket ticket = new Ticket();

        new Thread(()->{
            for (int i = 0; i < 50; i++) {
                ticket.sale();
            }
        },"A").start();

        new Thread(()->{
            for (int i = 0; i < 50; i++) {
                ticket.sale();
            }
        },"B").start();

        new Thread(()->{
            for (int i = 0; i < 50; i++) {
                ticket.sale();
            }
        },"C").start();

    }
}

class Ticket{
    private int number = 50;
    int i = 0;

    public synchronized void sale(){
        if(number > 0){
            System.out.println(Thread.currentThread().getName() + "卖出了第" + (++i) + "张票,剩余:" + --number);
        }
    }
}

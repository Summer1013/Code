package com.yuwei.ReadWrite;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * @author 于伟
 * 做什么:测试ReadWriteLockDemo
 * 独占锁(写锁) 一次只能被一个线程占有
 * 共享锁(读锁) 可以被多个线程同时占有
 * 读-读  可以共存
 * 读-写  不可以共存
 * 写-写  不可以共存
 */
public class ReadWriteLockDemo {
    public static void main(String[] args) {
        MyCache myCache = new MyCache();
        MyCacheLock myCacheLock = new MyCacheLock();

        ////写入  非加锁
        //for (int i = 1; i <= 5; i++) {
        //    final int temp = i;
        //    new Thread(()->{
        //        myCache.put(temp+"",temp+"");
        //    },String.valueOf(i)).start();
        //}
        ////读取  非加锁
        //for (int j = 1; j <= 5; j++) {
        //    final int temp = j;
        //    new Thread(()->{
        //        myCache.get(temp+"");
        //    },String.valueOf(j)).start();
        //}

        //写入  加锁
        for (int m = 1; m <= 5; m++) {
            final int temp = m;
            new Thread(()->{
                myCacheLock.put(temp+"",temp+"");
            },String.valueOf(m)).start();
        }

        //读取  加锁
        for (int n = 1; n <= 5; n++) {
            final int temp = n;
            new Thread(()->{
                myCacheLock.get(temp+"");
            },String.valueOf(n)).start();
        }



    }
}

//自定义缓存  加锁
class MyCacheLock{
    private volatile Map<String,Object> map = new HashMap<>();
    //读写锁 更加细粒度的控制
    private ReadWriteLock readWriteLock = new ReentrantReadWriteLock();

    //写入put  同一时刻 只有一个线程去写
    public void put(String key, Object value){
        readWriteLock.writeLock().lock();
        try {
            System.out.println(Thread.currentThread().getName() + "写入" + key);
            map.put(key,value);
            System.out.println(Thread.currentThread().getName() + "写入完毕" + key);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            readWriteLock.writeLock().unlock();
        }
    }

    //读取get  同一线程 可以多个线程去读
    public void get(String key){
        readWriteLock.readLock().lock();
        try {
            System.out.println(Thread.currentThread().getName() + "读取" + key);
            map.get(key);
            System.out.println(Thread.currentThread().getName() + "读取完毕" + key);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            readWriteLock.readLock().unlock();
        }
    }
}

//自定义缓存  不加锁
class MyCache{
    private Map<String,Object> map = new HashMap<>();

    //写入put
    public void put(String key, Object value){
        System.out.println(Thread.currentThread().getName() + "写入" + key);
        map.put(key,value);
        System.out.println(Thread.currentThread().getName() + "写入完毕" + key);
    }

    //读取get
    public void get(String key){
        System.out.println(Thread.currentThread().getName() + "写入" + key);
        map.get(key);
        System.out.println(Thread.currentThread().getName() + "写入完毕" + key);
    }
}

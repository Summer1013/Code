package com.yuwei.forkjoin;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.stream.LongStream;

/**
 * @author 于伟
 * 做什么:
 */
public class Test {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        test01();//7036  普通
        test02();//4899  用forkjoin
        test03();//287   用Stream
    }

    //普通程序员
    public static void test01(){
        Long sum = 0L;
        long start = System.currentTimeMillis();
        for (Long i = 1L; i <= 10_0000_0000; i++) {
            sum += i;
        }
        long end = System.currentTimeMillis();
        System.out.println("sum=" + sum + " 时间" + (end - start));
    }

    //中等程序员  会使用forkjoin
    public static void test02() throws ExecutionException, InterruptedException {
        long start = System.currentTimeMillis();
        ForkJoinPool forkJoinPool = new ForkJoinPool();//new一个
        ForkJoinTask<Long> task = new forkjoinDemo(0L, 10_0000_0000L);
        ForkJoinTask<Long> submitResult = forkJoinPool.submit(task);//提交任务
        Long sum = submitResult.get();//得到最终结果
        long end = System.currentTimeMillis();
        System.out.println("sum=" + sum + " 时间" + (end - start));
    }

    //高级程序员 会使用Stream并行流
    public static void test03(){
        long start = System.currentTimeMillis();
        long sum = LongStream
                .rangeClosed(0L, 10_0000_0000L)
                .parallel()
                .reduce(0, Long::sum);
        long end = System.currentTimeMillis();
        System.out.println("sum=" + sum + " 时间" + (end - start));
    }
}

package com.yuwei.forkjoin;

import java.util.concurrent.RecursiveTask;

/**
 * @author 于伟
 * 做什么:如何使用ForkJoin
 * 1.ForkJoinPool 通过它来执行
 * 2.计算任务 forkjoinpool.executor(ForkJoinTask task)
 * 3.计算类要去继承 ForkJoinTask
 */
//
public class forkjoinDemo extends RecursiveTask<Long> {
    private Long start;  //1
    private Long end;    //1990900000

    //临界值
    private Long temp = 10000L;

    public forkjoinDemo(Long start, Long end) {
        this.start = start;
        this.end = end;
    }

    //计算方法
    @Override
    protected Long compute() {
        if((end - start) < temp){
            Long sum = 0L;
            for (Long i = start; i <= end; i++) {
                sum += i;
            }
            return sum;
        }else {
            long middle = (start + end) / 2;//中间值
            forkjoinDemo task1 = new forkjoinDemo(start, middle);
            task1.fork();// 拆分任务 把任务压入线程队列
            forkjoinDemo task2 = new forkjoinDemo(middle + 1, end);
            task2.fork();// 拆分任务 把任务压入线程队列
            return task1.join() + task2.join();//将结果加起来
        }
    }
}

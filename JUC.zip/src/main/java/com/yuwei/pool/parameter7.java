package com.yuwei.pool;

import java.util.concurrent.*;

/**
 * @author 于伟
 * 做什么:ThreadPoolExecutor
 */
public class parameter7 {
    public static void main(String[] args) {
        //public ThreadPoolExecutor(int corePoolSize,
        //核心线程池大小   类似于银行此时可以办理业务的窗口  2
        //int maximumPoolSize,
        //最大核心线程池大小  类似于银行办理业务的总窗口    5
        //long keepAliveTime,
        //超时了没有人调用就会释放  类似于除了银行常开的2个窗口外  其他窗口没事做到指定时间就停止办理业务
        //TimeUnit unit,
        //指定时间的单位
        //BlockingQueue<Runnable> workQueue,
        //阻塞队列 类似于银行等候区的人
        //ThreadFactory threadFactory,
        //线程工厂  创建线程的  一般不用动
        //RejectedExecutionHandler handler
        //拒绝策略  如果最大线程池加上队列都满了 有四种拒绝策略
        //new ThreadPoolExecutor.AbortPolicy//银行满了 还有人进来 不处理这个人的 抛出异常
        //new ThreadPoolExecutor.CallerRunsPolicy//哪里来的回哪里
        //new ThreadPoolExecutor.DiscardPolicy//队列满了 丢掉任务 不会排除异常
        //new ThreadPoolExecutor.DiscarOldPolicy//队列满了 尝试和最早的去竞争 不会抛出异常
        //
        //
        //
        //
        //
        // ) {
        //    if (corePoolSize < 0 ||
        //            maximumPoolSize <= 0 ||
        //            maximumPoolSize < corePoolSize ||
        //            keepAliveTime < 0)
        //        throw new IllegalArgumentException();
        //    if (workQueue == null || threadFactory == null || handler == null)
        //        throw new NullPointerException();
        //    this.corePoolSize = corePoolSize;
        //    this.maximumPoolSize = maximumPoolSize;
        //    this.workQueue = workQueue;
        //    this.keepAliveTime = unit.toNanos(keepAliveTime);
        //    this.threadFactory = threadFactory;
        //    this.handler = handler;
        //}
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(
                2,//2个一直开启的线程
                5,//总线程数
                2,//如果线程超过两个 且忙的过来  就等待2秒就关闭2个线程以外的线程
                TimeUnit.SECONDS,//单位
                new LinkedBlockingDeque<>(3),//总等候线程数
                Executors.defaultThreadFactory(),//默认的线程工厂 一般不动
                new ThreadPoolExecutor.CallerRunsPolicy()
        );
        try {
            for (int i = 0; i < 100; i++) {
                threadPoolExecutor.execute(()->{
                    System.out.println(Thread.currentThread().getName());
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            threadPoolExecutor.shutdown();
        }
    }
}

package com.yuwei.pool;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @author 于伟
 * 做什么:线程池的三大方法
 */
public class method3 {
    public static void main(String[] args) {
        //test01();
        //test02();
        test03();
    }

    //单个线程
    public static void test01(){
        ExecutorService threadPool = Executors.newSingleThreadExecutor();

        try {
            for (int i = 0; i < 20; i++) {
                final int temp = i;
                threadPool.execute(()->{
                    System.out.println(temp + "  " + Thread.currentThread().getName());
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            threadPool.shutdown();
        }
    }

    //固定线程
    public static void test02(){
        ExecutorService threadPool = Executors.newFixedThreadPool(10);

        try {
            for (int i = 0; i < 20; i++) {
                final int temp = i;
                threadPool.execute(()->{
                    System.out.println(temp + "  " + Thread.currentThread().getName());
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            threadPool.shutdown();
        }
    }

    //可伸缩线程 遇强则强 遇弱则弱
    public static void test03(){
        ExecutorService threadPool = Executors.newCachedThreadPool();

        try {
            for (int i = 0; i < 100; i++) {
                final int temp = i;
                threadPool.execute(()->{
                    System.out.println(temp + "  " + Thread.currentThread().getName());
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            threadPool.shutdown();
        }
    }
}

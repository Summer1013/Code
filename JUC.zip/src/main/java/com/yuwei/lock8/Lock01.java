package com.yuwei.lock8;

import java.util.concurrent.TimeUnit;

/**
 * @author 于伟
 * 做什么:八锁现象  第一个
 * 1.syn修饰的发短信方法先执行还是syn修饰的打电话方法先执行
 * 答案:发短信   打电话
 * 2.让syn修饰的发短信方法休眠四秒看谁先执行
 * 答案:发短信   打电话
 * 3.增加一个普通方法hello 看看是syn修饰的发短信方法先执行还是普通方法hello先执行
 * 答案:hello   发短信  因为发短信前有4s休眠
 * 4.增加一个phone对象 用phone2对象去调用syn修饰的call方法 看谁先执行
 * 答案:打电话   发短信   因为发短信前有4s休眠  两个对象表示两个不同的锁
 * 5.增加两个静态syn方法 只有一个对象 看是打电话先执行还是发短信先执行
 * 答案:发短信   打电话   静态方法锁的就是class对象
 * 6.增加一个对象 两个对象  看是打电话先执行还是发短信先执行
 * 答案:发短信  打电话   class对象一个类只有一个
 * 7.一个静态syn方法  一个非静态syn方法  先执行谁
 * 答案:打电话  发短信
 * 8.一个静态syn方法  一个非静态syn方法 两个对象 先执行谁
 * 答案:打电话  发短信
 *
 * 小结:
 * synchronized 锁的是phone对象
 * static synchronized锁的是class模板
 */
public class Lock01 {
    public static void main(String[] args) throws InterruptedException {
        Phone phone1 = new Phone();
        Phone phone2 = new Phone();

        //1.syn修饰的发短信方法先执行还是syn修饰的打电话方法先执行
        //new Thread(()->{phone1.sendMes();}).start();
        //TimeUnit.SECONDS.sleep(1);
        //new Thread(()->{phone1.call();}).start();

        //2.让syn修饰的发短信方法休眠四秒看谁先执行
        //new Thread(()->{phone1.sendMes();}).start();
        //TimeUnit.SECONDS.sleep(1);
        //new Thread(()->{phone1.call();}).start();

        //3.增加一个普通方法hello 看看是syn修饰的发短信方法先执行还是普通方法hello先执行
        //new Thread(()->{phone1.sendMes();}).start();
        //TimeUnit.SECONDS.sleep(1);
        //new Thread(()->{phone1.hello();}).start();

        //4.增加一个phone对象 用phone2对象去调用syn修饰的call方法 看谁先执行
        //new Thread(()->{phone1.sendMes();}).start();
        //TimeUnit.SECONDS.sleep(1);
        //new Thread(()->{phone2.call();}).start();

        //5.增加两个静态syn方法 只有一个对象 看是打电话先执行还是发短信先执行
        //new Thread(()->{phone1.sendMesStatic();}).start();
        //TimeUnit.SECONDS.sleep(1);
        //new Thread(()->{phone1.callStatic();}).start();

        //6.增加一个对象 两个对象  看是打电话先执行还是发短信先执行
        //new Thread(()->{phone1.sendMesStatic();}).start();
        //TimeUnit.SECONDS.sleep(1);
        //new Thread(()->{phone2.callStatic();}).start();

        //7.一个静态syn方法  一个非静态syn方法  先执行谁
        //new Thread(()->{phone1.sendMesStatic();}).start();
        //TimeUnit.SECONDS.sleep(1);
        //new Thread(()->{phone1.call();}).start();

        //8.一个静态syn方法  一个非静态syn方法 两个对象 先执行谁
        //new Thread(()->{phone1.sendMesStatic();}).start();
        //TimeUnit.SECONDS.sleep(1);
        //new Thread(()->{phone2.call();}).start();
    }
}
class Phone {

    //synchronized 锁的对象是方法的调用者
    //两个方法用的是同一个锁,谁先拿到谁执行
    public synchronized void sendMes(){
        try {
            TimeUnit.SECONDS.sleep(2);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("发短信");
    }

    public static synchronized void sendMesStatic(){
        try {
            TimeUnit.SECONDS.sleep(2);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("发短信");
    }

    public synchronized void call(){
        System.out.println("打电话");
    }

    public static synchronized void callStatic(){
        System.out.println("打电话");
    }

    public void hello(){
        System.out.println("hello");
    }

}

package com.yuwei.BQ;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * @author 于伟
 * 做什么:阻塞队列
 * 1.如果队列满了再添加或者队列为空再移除  就会抛出异常
 * 2.如果队列满了再添加或者队列为空再移除  就会返回false
 * 3.如果队列满了再添加或者队列为空再移除  就会一直等待
 * 4.如果队列满了再添加或者队列为空再移除  可以设置等待时间  等待时间一过就会添加失败或者移除失败
 */
public class BlockingQueueDemo {
    public static void main(String[] args) throws InterruptedException {
        //test1();
        //test2();
        //test3();
        test4();

    }

    //抛出异常
    public static void test1(){
        //参数为队列的大小
        ArrayBlockingQueue blockingQueue = new ArrayBlockingQueue<>(3);

        //添加
        System.out.println(blockingQueue.add("a"));
        System.out.println(blockingQueue.add("b"));
        System.out.println(blockingQueue.add("c"));
        System.out.println(blockingQueue);

        //查看队首元素
        System.out.println(blockingQueue.element());

        //再添加的话就超出了队列的大小  会抛出异常
        //java.lang.IllegalStateException: Queue full  队列已满
        //System.out.println(blockingQueue.add("d"));

        //移除
        blockingQueue.remove();
        blockingQueue.remove();
        blockingQueue.remove();
        System.out.println(blockingQueue);

        //队列此时为空 再移除会抛出异常
        //java.util.NoSuchElementException 队列没有元素
        //blockingQueue.remove();
    }

    //有返回值  不抛出异常
    public static void test2(){
        //参数为队列的大小
        ArrayBlockingQueue blockingQueue = new ArrayBlockingQueue<>(3);

        //添加
        System.out.println(blockingQueue.offer("a"));
        System.out.println(blockingQueue.offer("b"));
        System.out.println(blockingQueue.offer("c"));
        System.out.println(blockingQueue.offer("d"));

        //查看队首元素
        System.out.println(blockingQueue.peek());

        //移除
        System.out.println(blockingQueue.poll());
        System.out.println(blockingQueue.poll());
        System.out.println(blockingQueue.poll());
        System.out.println(blockingQueue);
    }

    //阻塞等待  一直等待
    public static void test3() throws InterruptedException {
        //参数为队列的大小
        ArrayBlockingQueue blockingQueue = new ArrayBlockingQueue<>(3);

        //添加
        blockingQueue.put("a");
        blockingQueue.put("b");
        blockingQueue.put("c");
        System.out.println(blockingQueue);
        //blockingQueue.put("d");//一直等待

        //移除
        blockingQueue.take();
        blockingQueue.take();
        blockingQueue.take();
        System.out.println("==============");
        blockingQueue.take();//一直等待
    }

    //阻塞等待  等待一段时间
    public static void test4() throws InterruptedException {
        //参数为队列的大小
        ArrayBlockingQueue blockingQueue = new ArrayBlockingQueue<>(3);

        //添加
        blockingQueue.offer("a");
        blockingQueue.offer("b");
        blockingQueue.offer("c");
        System.out.println("添加满了 等待两秒结束添加");
        blockingQueue.offer("d",2, TimeUnit.SECONDS);

        //移除
        blockingQueue.poll();
        blockingQueue.poll();
        blockingQueue.poll();
        System.out.println("队列元素为空 等待两秒结束移除");
        blockingQueue.poll(2,TimeUnit.SECONDS);
    }

}

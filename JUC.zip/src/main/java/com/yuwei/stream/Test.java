package com.yuwei.stream;

import java.util.Arrays;
import java.util.List;

/**
 * @author 于伟
 * 做什么:题目要求 一分钟完成 一行代码实现
 * 现在有5个用户 筛选
 * 1. ID必须是偶数
 * 2. 年龄必须大于23岁
 * 3. 用户名转为大写字母
 * 4. 用户名字字母倒着排序
 * 5. 只输出一个用户
 *
 */
public class Test {
    public static void main(String[] args) {
        User u1 = new User(1,"aa",23);
        User u2 = new User(2,"bb",23);
        User u3 = new User(3,"cc",24);
        User u4 = new User(4,"dd",25);
        User u5 = new User(6,"ee",26);

        List<User> usersList = Arrays.asList(u1, u2, u3, u4, u5);
        usersList.stream()
                .filter((u)->{return u.getId()%2 == 0;})//ID必须是偶数
                .filter((u)->{return u.getAge() > 23;})//年龄必须大于23岁
                .map((u)->{return u.getName().toUpperCase();})//用户名转为大写字母
                .sorted((user1,user2)->{return user1.compareTo(user2);})//用户名字字母倒着排序
                .limit(2)//只输出一个用户
                .forEach(System.out::println);
    }
}

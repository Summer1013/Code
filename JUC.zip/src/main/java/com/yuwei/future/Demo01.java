package com.yuwei.future;

import java.sql.Time;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

/**
 * @author 于伟
 * 做什么:异步回调  CompletableFuture
 * 异步回调
 * 成功回调
 * 失败回调
 */
public class Demo01 {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        //没有返回值的 runAsync  异步回调
        //CompletableFuture<Void> completableFuture = CompletableFuture.runAsync(()->{
        //    try {
        //        TimeUnit.SECONDS.sleep(2);
        //    } catch (InterruptedException e) {
        //        e.printStackTrace();
        //    }
        //    System.out.println(Thread.currentThread().getName());
        //});
        //System.out.println("1111");
        //completableFuture.get();//获取阻塞执行结果

        //有返回值的 supplyAsync  异步回调
        // ajax 成功和失败的回调
        // 返回的是错误信息
        CompletableFuture<Integer> completableFuture = CompletableFuture.supplyAsync(()->{
            System.out.println(Thread.currentThread().getName());
            int i = 10/0;
            return 1024;
        });

        //正常的是 t=1024 u=null
        //错误的是 t=null u=java.util.concurrent.CompletionException: java.lang.ArithmeticException: / by zero
        System.out.println(completableFuture.whenComplete((t, u) -> {
            System.out.println("t = " + t);//正确  t不为null  u为null
            System.out.println("u = " + u);//错误  t为null   u不为null
        }).exceptionally((e) -> {//如果supplyAsync 中有错误  就会执行这里
            System.out.println(e.getMessage());
            return 233;
        }).get());


    }
}

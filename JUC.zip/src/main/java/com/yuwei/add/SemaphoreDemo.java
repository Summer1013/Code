package com.yuwei.add;

import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

/**
 * @author 于伟
 * 做什么:6辆车去一个容量为3的地方停车
 */
public class SemaphoreDemo {
    public static void main(String[] args) {
        //停车场容量数
        Semaphore semaphore = new Semaphore(3);
        //6辆车
        for (int i = 0; i < 6; i++) {
            new Thread(()->{
                try {
                    //找到一个停车位
                    semaphore.acquire();
                    System.out.println(Thread.currentThread().getName() + "-->找到停车位");
                    TimeUnit.SECONDS.sleep(2);
                    System.out.println(Thread.currentThread().getName() + "-->离开停车位");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    //释放停车位
                    semaphore.release();
                }
            },String.valueOf(i)).start();
        }

    }
}

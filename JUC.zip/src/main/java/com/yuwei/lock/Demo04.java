package com.yuwei.lock;

/**
 * @author 夏天
 * 有bug请联系QQ:1205232048
 * 做什么:死锁如何处理
 */
public class Demo04 {
    public static void main(String[] args) {
        new Thread(new deadLock("A锁","B锁"),"A").start();
        new Thread(new deadLock("B锁","A锁"),"B").start();
    }
}
class deadLock implements Runnable{
    private String lockA;
    private String lockB;

    public deadLock(String lockA, String lockB) {
        this.lockA = lockA;
        this.lockB = lockB;
    }

    @Override
    public void run() {
        synchronized (lockA){
            System.out.println(Thread.currentThread().getName() + "拿到了" + lockA + "又想去拿" +lockB);

            synchronized (lockB){
                System.out.println(Thread.currentThread().getName() + "拿到了" + lockB + "又想去拿" +lockA);
            }
        }
    }
}

package com.yuwei.lock;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * @author 夏天
 * 有bug请联系QQ:1205232048
 * 做什么:用CAS自旋锁
 */
public class Demo03 {
    static AtomicReference<Thread> atomicReference = new AtomicReference();

    public static void main(String[] args) throws InterruptedException {
        new Thread(()->{
            MyLock();
            MyUnLock();
        },"A").start();

        TimeUnit.SECONDS.sleep(1);

        new Thread(()->{
            MyLock();
            MyUnLock();
        },"B").start();

    }

    public static void MyLock(){
        Thread thread = Thread.currentThread();
        int i = 1;
        System.out.println(Thread.currentThread().getName() + "==> mylock");
        while (!atomicReference.compareAndSet(null,thread)){
            System.out.println(i++);
        }
    }

    public static void MyUnLock(){
        Thread thread = Thread.currentThread();
        System.out.println(Thread.currentThread().getName() + "==> myunlock");
        atomicReference.compareAndSet(thread,null);
    }
}

package com.yuwei.callable_;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

/**
 * @author 于伟
 * 做什么:callable如何通过Thread调用
 * callable可以抛出异常  有返回值
 */
public class CallableDemo01 {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        MyThread myThread = new MyThread();
        FutureTask futureTask = new FutureTask<>(myThread);
        new Thread(futureTask,"A").start();
        new Thread(futureTask,"B").start();//结果会被缓存 效率高

        //返回值在futureTask中 调用get方法就可以得到
        //这个get方法必须等call方法全部执行完才能得到返回值  所以可能造成阻塞
        //一般放到最后一行  或者采用后面学的异步通信方式处理
        String s = (String) futureTask.get();
        System.out.println(s);
    }
}
class MyThread implements Callable<String>{
    @Override
    public String call() throws Exception {
        System.out.println("call()");
        return "调用成功";
    }
}

package com.yuwei.volatiletest;

import java.util.concurrent.TimeUnit;

/**
 * @author 于伟
 * 做什么:不加volatile会进入死循环
 * 加了volatile可以保证可见性
 */
public class jmm {
    private volatile static int i = 0;
    public static void main(String[] args) throws InterruptedException {
        new Thread(()->{
            while (i == 0){

            }
        }).start();

        TimeUnit.SECONDS.sleep(2);

        i = 1;
        System.out.println(i);
    }
}

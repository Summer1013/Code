package com.hspedu.test;

public class ExtendsDetail {
    public static void main(String[] args) {
        Sub sub = new Sub();
        System.out.println("hello");

    }
}

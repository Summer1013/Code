package com.hspedu.test;

public class A {

    //四个属性,分别使用不同的访问修饰符来修饰
    public int n1 = 100;
    protected int n2 = 200;
    int n3 = 300;
    private int n4 = 400;
    public void test100() {}
    protected void test200() {}
    void test300() {}
    private void test400() {}
}


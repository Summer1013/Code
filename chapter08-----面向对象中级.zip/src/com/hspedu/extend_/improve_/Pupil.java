package com.hspedu.extend_.improve_;

//让Pupil 继承 Student类
public class Pupil extends Student {
    public void testing() {
        System.out.println("小学生 " + name + "  正在考小学数学..");
    }
}

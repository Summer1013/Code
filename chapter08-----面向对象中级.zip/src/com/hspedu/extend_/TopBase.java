package com.hspedu.extend_;

public class TopBase { //父类是Object

    public TopBase() {
        //super(); Object的无参构造器
        System.out.println("构造器TopBase() 被调用...");//1
    }
}

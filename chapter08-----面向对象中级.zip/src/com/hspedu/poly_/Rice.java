package com.hspedu.poly_;

public class Rice extends Food {
    public Rice(String name) {
        super(name);
    }
}

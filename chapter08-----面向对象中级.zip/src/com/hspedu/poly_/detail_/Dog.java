package com.hspedu.poly_.detail_;

public class Dog extends Animal {//Dog是Animal的子类
}
